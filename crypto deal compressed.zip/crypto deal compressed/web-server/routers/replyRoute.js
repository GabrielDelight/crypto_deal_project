const router = require('express').Router();
const auth = require('./auth')
const User = require('../models/model')
const Post = require('../models/postModel');
const Comment = require('../models/comments')
const Reply = require('../models/replyComment')
const multer = require('multer')
const Notification = require('../models/notification')
const path = require('path')
const mysql = require('mysql');
const crypto = require('crypto')

// Set created date
let monthsArray;
let month;
let newMonth;
let day = new Date().getDay();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = `${year} ${newMonth} ${day}`

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})



db.connect((error) => {
    if (error) {
        console.log(error)
    }
})



module.exports = function (io) {
    // Reply message
    router.get('/replyComment/:id', auth, async (req, res) => {
        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = users[0]

            const comments = await User(`SELECT * FROM comments WHERE _id='${req.params.id}'`)
            const replies = await User(`SELECT * FROM replies WHERE mainCommentId='${comments[0]._id}'`)

            res.render('replyPage', {
                data: comments[0],
                user: user,
                replies: replies,
                users
            })

        } catch (error) {
            console.log(error)
            res.render('404Page')
        }

    })

    // @ set up validation for image upload
    const storage = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/commentImages',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const upload = multer({
        // limits: 300000,
        storage: storage
    })

    // Creating a reply commetn
    router.post('/saveReplyComment', auth, upload.single('uploadImg'), async (req, res) => {

        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = users[0]

            const comments = await User(`SELECT * FROM comments WHERE _id='${req.body.mainCommentId}'`)
            let commentOwner = comments[0]

            // const commentData = await Comment.findById(req.body.mainCommentId)

            const owner = user._id;
            const fullName = `${user.firstname} ${user.lastname}`;
            const comment = req.body.comment;
            const mainCommentId = req.body.mainCommentId

            let image
            let hidePhoto = 'none'
            if (req.file) {
                image = req.file.filename
                hidePhoto = 'block'
            }

            const _id = crypto.randomBytes(12).toString('hex')

            const saveReply = {
                date: fullDateStr,
                owner,
                _id,
                comment,
                fullName,
                mainCommentId,
                image,
                hidePhoto,
                commentorNickName: user.fullName,
                verified: user.verified,
                avatar: user.avatar
            }

            let sql = 'INSERT INTO replies SET ?'
            db.query(sql, saveReply, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // Counting numbers of replies in a comment
            let updateRepliesLength = `UPDATE comments SET replylength='${req.body.commentLength}' WHERE _id='${comments[0]._id}'`
            db.query(updateRepliesLength, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Add last replies in comment
            let updateLastComment = `UPDATE comments SET lastPostOwnerId='${user._id}',lastReplyAvatar='${user.avatar}',lastReplyName='${user.firstname} ${user.lastname}',lastReplyVerified='${user.verified}',lastReplyText='${req.body.comment}',hideReply='block' WHERE _id='${comments[0]._id}'`

            db.query(updateLastComment, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            const checkowner = commentOwner.owner.toString() !== user._id.toString()
            if (checkowner) {
                const notification = {
                    owner: user._id,
                    _id: crypto.randomBytes(12).toString('hex'),
                    text: 'Replied to your comment',
                    comment: req.body.comment,
                    eventId: mainCommentId,
                    eventOwner: commentOwner.owner,
                    date: fullDateStr,
                    ownerName: `${user.firstname} ${user.lastname}`,
                    avatar: user.avatar,
                    urlLink: `replyComment/${mainCommentId}`
                }

                let sql = 'INSERT INTO notification SET ?'
                db.query(sql, notification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                let findNotifcationOwner = await User(`SELECT * FROM users WHERE _id='${commentOwner.owner}'`)
                let eventOwner = findNotifcationOwner[0]
                if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                    let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${commentOwner.owner}'`
                    db.query(sql, (error) => {
                        if (error) return console.log(error)
                    })
                    res.redirect(`/replyComment/${mainCommentId}`)
                    return
                } else {
                    let count = parseInt(eventOwner.notifiicationLength)
                    count = count += 1
                    let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${commentOwner.owner}'`
                    db.query(sqlQueryForCOunt, (error) => {
                        if (error) return console.log(error)
                    })
                }

                res.redirect(`/replyComment/${mainCommentId}`)
                return

            }



            res.redirect(`/replyComment/${mainCommentId}`)
        } catch (error) {
            console.log(error)
            res.redirect(`/replyComment/${mainCommentId}`)
        }

    })


    // SServer upload image
    router.get('/uploadForReply/:id', async (req, res) => {
        const reply = await Reply.findById(req.params.id);
        res.set('Content-Type', 'image/png')
        res.send(reply.image)

    })


    // Reaction 
    io.on('connection', (socket) => {
        socket.on('reactionForReplyDetails', async (data) => {
            let userId = data.userId;
            let replyId = data.commentId;


            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
            const replies = await GETSQL(`SELECT * FROM replies WHERE _id='${replyId}'`)
            let user = userx[0]
            let reply = replies[0]


            async function notificationFunction() {
                // const getCommentId = await Comment.findById(reply.mainCommentId) //to get comment link 
                const getCommentId = await GETSQL(`SELECT * FROM comments WHERE _id='${reply.mainCommentId}'`)
                const checkowner = reply.owner.toString() !== user._id.toString()
                if (checkowner) {
                    // Send notification    
                    let randomId = crypto.randomBytes(12).toString('hex')

                    const notification = {
                        owner: userId,
                        _id: randomId,
                        text: 'Reacted to your comment',
                        comment: reply.comment,
                        eventId: reply._id,
                        eventOwner: reply.owner,
                        date: fullDateStr,
                        avatar: user.avatar,
                        ownerName: `${user.firstname} ${user.lastname}`,
                        urlLink: 'replyComment/' + getCommentId[0]._id

                    }

                    let sql = 'INSERT INTO notification SET ?'
                    db.query(sql, notification, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('Created a new Nitification')
                    })


                    let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${reply.owner}'`)
                    let eventOwner = findNotifcationOwner[0]
                    if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                        let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${reply.owner}'`
                        db.query(sql, (error) => {
                            if (error) return console.log(error)
                        })
                        return
                    } else {
                        let count = parseInt(eventOwner.notifiicationLength)
                        count = count += 1
                        let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${reply.owner}'`
                        db.query(sqlQueryForCOunt, (error) => {
                            if (error) return console.log(error)
                        })
                    }

                }
            }


            // @ if post reaction is empty add the first value to it
            if (reply.reaction == '' || reply.reaction == null) {
                let sql = `UPDATE replies SET reaction='${user.id}', reactionLength='${1}' WHERE _id='${reply._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Likeed')
                })
                notificationFunction()
                return
            }


            const reaction = reply.reaction.split(',')
            let newReaction = reaction.map(el => {
                return parseInt(el)
            })

            let index = newReaction.indexOf(user.id)

            // @ remove like
            if (index > -1) {
                newReaction.splice(index, 1)

                let sql = `UPDATE replies SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${reply._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                return
            }

            // @ add like
            newReaction.push(user.id)
            let sql = `UPDATE replies SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${reply._id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
            notificationFunction()

        })
    })


    // Delete my reply *********************************
    router.get('/deleteMyReply/:id', async (req, res) => {

        async function SQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const replies = await SQL(`SELECT * FROM replies WHERE _id='${req.params.id}'`)
        const comment = await SQL(`SELECT * FROM comments WHERE _id='${replies[0].mainCommentId}'`)


        let sql = `DELETE  FROM replies WHERE _id='${req.params.id}'`
        db.query(sql, (error, result) => {
            if (error) {
                return console.log(error)
            }
        })

        res.redirect(`/replyComment/${comment[0]._id}`)

        const decreaseComment = await SQL(`SELECT * FROM replies WHERE mainCommentId='${replies[0].mainCommentId}'`)

        let updatesql = `UPDATE comments SET replyLength='${decreaseComment.length}' WHERE id='${comment[0].id}'`
        db.query(updatesql, (error) => {
            if (error) {
                return console.log(error)
            }
        })

    })
    return router
}