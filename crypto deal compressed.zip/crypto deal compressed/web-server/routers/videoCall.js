const router = require('express').Router()
const auth = require('./auth')
const User = require('../models/model')
const Peer = require('simple-peer')



module.exports = function (io) {

    router.get('/start-calling/:id', auth, async (req, res) => {
        try {
            const user = await User.findById(req.user)
            const receiver = await User.findById(req.params.id)
            if (!receiver) {
                return res.render('404Page')
            }
            res.render('videoCalling', {
                user,
                receiver,
                peerType: 'init',
                title: 'Calling ' + user.firstname + ' ' + user.lastname,
            })

        } catch (error) {
            res.render('404Page')
            console.log(error.message) 
        }
    })

    
    router.get('/incoming-call/:id', auth, async (req, res) => {
        try {
            const user = await User.findById(req.user)
            const caller = await User.findById(req.params.id)
            if (!caller) {
                return res.render('404Page')
            }
            res.render('incomingCall', {
                user,
                caller,
                title: 'Incoming call from ' + user.firstname + ' ' + user.lastname,
                peerType: 'not init'


            })

        } catch (error) {
            return res.render('404Page')
        }
    })





    io.on('connection', (socket) => {

        socket.on('fetchVideoCallReceiver', data => {
            io.emit('lookUpForReceiver', data)
        })

        // receiver quitting call
        socket.on('cancelingVideoRequest', data => {
            io.emit('calcelRequest', data)
        })

        // caller quitting call
        socket.on('sendCallerQuitting', id => {
            io.emit('callQuitting', id)
        })

        // listen that receiver accepted
        socket.on('receiverAccepted', id => {
            io.emit('openCallerVideo', id)
        })

        // listening to peerid to be sent to receiver
        socket.on('sendPeeingId', data => {
            socket.broadcast.emit('sendPeeridToReceiverTextArea', data)
        })


        // tellling caller that receiver is ready
        socket.on('receiverIsReady', id => {
            io.emit('readyToPeer', id)
        })

        socket.on('sendMyPeerIdToReceiver', data => {
            setTimeout(() => {
                io.emit('gettingPerrIdFromInit', data)
            }, 5000)
        })

        // signal that users answered the call and send it back to the caller 
        socket.on('signalThatUserAnswered', (data) => {
            io.emit('openCallerVideo', data)
        })







    })

    return router
}