const router = require('express').Router();
const User = require('../models/model')
const Post = require('../models/postModel')
const auth = require('./auth')
const ChatNotification = require('../models/chatNotification')
const SentChatNotification = require('../models/sentCHatNotification')
const Notification = require('../models/notification')
const mysql = require('mysql')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})



db.connect((error) => {
    if (error) {
        console.log(error)
    }
})


router.get('/search', auth, async (req, res) => {
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }
    const userx = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let user = userx[0]


    res.render('search', {
        user,
        hideDiv: 'none',
    })
})



router.post('/search', auth, async (req, res) => {
    // Serach for users
    async function User(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }
    const userx = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let user = userx[0]

    let search = req.body.search
    let allusers = await User(`SELECT * FROM users`)
    let addWithNames = []
    for (i = 0; i < allusers.length; i++) {
        if (allusers[i].fullName.includes(search)) {
            addWithNames.push(allusers[i].fullName)
        }
    }

    let arrWithUsers = []
    for (i = 0; i < addWithNames.length; i++) {
        let foundUsers = await User(`SELECT * FROM users WHERE fullName='${addWithNames[i]}'`)
        foundUsers.forEach(cur => {
            arrWithUsers.push(cur)
        })
    }

    // Search for post
    const posts = await User(`SELECT * FROM posts`)

    let postDescriptionArray = []
    for (i = 0; i < posts.length; i++) {
        if(posts[i].description.includes(search.toLowerCase())){
            postDescriptionArray.push(posts[i].description.toLowerCase())
        }
    }
    // Search for post
    let postText = []
    for (i = 0; i < postDescriptionArray.length; i++) {
        let foundPostText = await User(`SELECT * FROM posts WHERE postType='text' AND description='${postDescriptionArray[i]}'`)
        foundPostText.forEach(cur => {
            postText.push(cur)
        })
    }


    let postImage = []
    for (i = 0; i < postDescriptionArray.length; i++) {
        let foundpostImage = await User(`SELECT * FROM posts WHERE postType='image' AND description='${postDescriptionArray[i]}'`)
        foundpostImage.forEach(cur => {
            postImage.push(cur)
        })
    }


    let postVideo = []
    for (i = 0; i < postDescriptionArray.length; i++) {
        let foundpostVideo = await User(`SELECT * FROM posts WHERE postType='video' AND description='${postDescriptionArray[i]}'`)
        foundpostVideo.forEach(cur => {
            postVideo.push(cur)
        })
    }



    res.render('search', {
        searchUsers: arrWithUsers,
        user,
        hideDiv: 'none',
        searchedQuery: search,
        image: postImage,
        text: postText,
        video: postVideo
    })
})
module.exports = router