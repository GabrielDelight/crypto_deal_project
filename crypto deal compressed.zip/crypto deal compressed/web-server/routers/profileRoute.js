const router = require('express').Router();
const multer = require('multer')
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }
})



router.get('/profile/:id', auth, async (req, res) => {
    try {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users WHERE _id='${val}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(req.user._id)
        const user = userSQL[0]


        // Get all users
        async function AllUsers(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users`
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const allUser = await AllUsers(req.user._id)
        const suggestedFollowers = await AllUsers(req.user._id)

        async function POST(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const textPost = await POST(`SELECT * FROM posts WHERE postType='text' AND owner='${req.params.id}'`)
        const photoPost = await POST(`SELECT * FROM posts WHERE postType='image' AND owner='${req.params.id}'`)
        const videoPost = await POST(`SELECT * FROM posts WHERE postType='video'AND owner='${req.params.id}'`)
        const sharedPostText = await POST(`SELECT * FROM sharepost WHERE postType='text'AND owner='${req.params.id}'`)
        const sharedPostImage = await POST(`SELECT * FROM sharepost WHERE postType='image'AND owner='${req.params.id}'`)
        const sharedPostVideo = await POST(`SELECT * FROM sharepost WHERE postType='video'AND owner='${req.params.id}'`)

        const paramsuUser = await POST(`SELECT * FROM users WHERE _id='${req.params.id}'`)


        // @ get post likes
        const postLength = await POST(`SELECT * FROM posts WHERE owner='${req.params.id}'`)
        const sharePostLength = await POST(`SELECT * FROM sharepost WHERE owner='${req.params.id}'`)
        let postLikes = []
        if (postLength.length > 0) {
            postLength.forEach(cur => {
                if (cur.reactionLength != null) {
                    postLikes.push(cur.reactionLength)
                }
            })
        }

        if (sharePostLength.length > 0) {
            sharePostLength.forEach(cur => {
                if (cur.reactionLength != null) {
                    postLikes.push(cur.reactionLength)
                }
            })
        }
        if (postLikes.length == 0) postLikes = [0]
        postLikes = postLikes.map(val => parseInt(val)).reduce((a, b) => a + b)



        // @ Get all the params user comment
        const allComment = await POST(`SELECT * FROM comments WHERE owner='${req.params.id}'`)


        //@ Create suggestion fot user to follow____________________
        const allUsers = await POST(`SELECT * FROM users`)
        let myFolloingArr = user.following + user.id
        let notFollowingIdsArray = []
        for (i = 0; i < allUsers.length; i++) {
            if (!myFolloingArr.includes(allUsers[i].id)) {
                notFollowingIdsArray.push(allUsers[i].id)
            }
        }

        let newUserTOFollow = []
        for (i = 0; i < notFollowingIdsArray.length; i++) {
            const fetchUsersToFollow = await POST(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
            fetchUsersToFollow.forEach(val => {
                newUserTOFollow.push(val)
            })
        }

        newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
        newUserTOFollow = newUserTOFollow.splice(0, 4)
        // @_______________________________________________________

        // @ get four (4) post 
        let allPostsSuggestedPost = await POST(`SELECT * FROM posts WHERE postType='image'`)
        allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
        allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)

        // get reaction
        let notification = await POST(`SELECT * FROM notification WHERE eventOwner='${user._id}' ORDER BY id DESC`)


        // Get all post liked by user
        // let getAllPosts = await POST(`SELECT * FROM posts`)
        // let likedPostArray = []
        // for (i = 0; i < getAllPosts.length; i++) {
        //     likedPostArray.push(getAllPosts[i].reaction)
        // }



        res.render('profile', {
            user,
            text: textPost,
            image: photoPost,
            video: videoPost,
            paramsuUser: paramsuUser[0],
            sharedPostText,
            sharedPostImage,
            sharedPostVideo,
            mainUser: user,
            postLength: postLength.length + sharePostLength.length,
            totalLikes: postLikes,
            paramsComment: allComment,
            suggestedArr: newUserTOFollow,
            posts: allPostsSuggestedPost,
            notification,
            // profilePicture,
            // users: users,
            // chatNotification,
            // sentChatNotification,
            // myIdOnPostsArr,

        })

    } catch (error) {
        console.log(error)
        // res.render('404Page')
    }

})

module.exports = router