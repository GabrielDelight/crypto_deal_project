const router = require('express').Router();
const multer = require('multer')
const auth = require('./auth');
const path = require('path');
const fs = require('fs')
const mysql = require('mysql')
const crypto = require('crypto');


const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})



db.connect((error) => {
    if (error) {
        console.log(error)
    }

})

// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/stories',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})


// Set created date
let monthsArray;
let month;
let newMonth;
let day = new Date().getDate();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = ` ${day} ${newMonth},  ${year}`


const videoUpload = multer({
    limits: 600000,
    fileFilter(req, file, cb) {
        if (!file.originalname.match(/\.(mp4|MP4|ogg|OGG)/)) {
            return cb(new Error('FIle must be a video'))
        }
        cb(undefined, true)
    }
})


module.exports = function (io) {
    // Auto delete story
    setTimeout(async () => {
        async function GETSQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const storyies = await GETSQL(`SELECT * FROM story `)


        storyies.forEach(async val => {
            if (val.storyHour == new Date().getHours() && val.exprireStoryNextDay == new Date().getDay()) {
                let sql = `UPDATE story SET isDisabled='true' WHERE id='${val.id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
            }
        })
    }, 1000);



    router.post('/uploadStatus', auth, upload.single('uploads'), async (req, res) => {
        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            let storyHour = new Date().getHours()
            let exprireStoryNextDay = new Date().getDay()
            exprireStoryNextDay = exprireStoryNextDay += 1

            // const user = await User.findById(req.user)
            let name = `${user.firstname} ${user.lastname}`
            const time = new Date().toLocaleTimeString()

            const _id = crypto.randomBytes(12).toString('hex')

            const story = {
                _id,
                caption: req.body.storyText,
                color: req.body.color,
                image: req.file.filename,
                sttoryImage: req.file.filename,
                owner: user._id,
                ownerName: name,
                storyStype: 'image',
                storyText: req.body.storyText,
                date: time,
                avatar: user.avatar,
                isDisabled: 'false',
                storyHour,
                exprireStoryNextDay
            }


            let sql = 'INSERT INTO story SET ?'
            db.query(sql, story, (error) => {
                if (error) {
                    return console.log(error)
                }
            })



            let sql2 = `UPDATE users SET hasStory='true',storyImg='${req.file.filename}', hasStory='true' WHERE _id='${user._id}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            res.redirect('/home')

        } catch (error) {
            console.log(error)
            res.redirect('/home')
        }

    }, (error, req, res, next) => {
        console.log(error)
        res.redirect('/home')
    })


    // // Uploading story video
    // router.post('/uploadVideoStatus', auth, videoUpload.single('uploadVideo'), async (req, res) => {
    //     try {
    //         const user = await User.findById(req.user)
    //         let name = `${user.firstname} ${user.lastname}`
    //         const time = new Date().toLocaleTimeString()
    //         const story = new Story({
    //             caption: req.body.storyText,
    //             color: req.body.color,
    //             video: req.file.buffer,
    //             owner: req.user._id,
    //             ownerName: name,
    //             storyStype: 'video',
    //             date: time
    //         })
    //         await story.save();

    //         // Help for sorting user that have uploaded a story
    //         user.hasStory = true
    //         await user.save()
    //         res.redirect('/home')

    //     } catch (error) {
    //         res.redirect('/home')
    //     }

    // }, (error, req, res, next) => {
    //     res.redirect('/home')
    // })    



    router.post('/deleteStory', async (req, res) => {
        try {
            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const storyies = await GETSQL(`SELECT * FROM story WHERE _id='${req.body.storyId}'`)

            // Set the story diablity to true
            let sql = `UPDATE story SET isDisabled='true' WHERE id='${storyies[0].id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            const allSTory = await GETSQL(`SELECT * FROM story WHERE _id='${req.body.storyId}' AND isDisabled='false'`)

            console.log(allSTory)


            const users = await GETSQL(`SELECT * FROM users WHERE _id='${storyies[0].owner}'`)
            let sql2 = `UPDATE users SET hasStory='false', storyImg='undefined' WHERE id='${users[0].id}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
            // console.log(users)



            // Delete the user story image

            // const allSTory = await Story.findOne({ _id: req.body.storyId, isDisabled: false })
            // if (!allSTory) {
            //     user.hasStory = false
            //     user.storyImg = undefined
            //     await user.save()
            // }


            // const story = await Story.findById(req.body.storyId)
            // const user = await User.findById(story.owner) // Owner from req.body in form
            // story.isDisabled = true
            // await story.save()
            // const storyImage = await Story.findById(req.body.storyId)
            // fs.unlink('./web-server/web-folder/public/webStorage/stories/' + storyImage.image, (error) => {
            //     if (!error) {
            //         console.log('Story deleted')
            //     }
            // })

            // check if the user has a story that equals false @ else change his has story to false


            res.redirect('/home')
        } catch (error) {
            res.redirect('/home')
        }

    })



    io.on('connection', (socket) => {
        socket.on('socketStory', async (data) => {
            try {

                async function STORY(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }

                const stories = await STORY(`SELECT * FROM story WHERE owner='${data.ownerId}' AND isDisabled='false' `)
                const storyOwner = await STORY(`SELECT * FROM users WHERE _id='${data.ownerId}'`)

                let story = stories[0]
                // console.log(story)

                // if there is no story delete the user story image and set the use hasStory to false
                if (!story) {
                    let sql2 = `UPDATE users SET hasStory='false', storyImg='undefined' WHERE id='${storyOwner[0].id}'`
                    db.query(sql2, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })

                    console.log('No story')
                    return
                }


                // @ send the story
                socket.emit('story', {
                    story: stories,
                    id: data.ownerId
                })



                // VIEWERS============================================
                const users = await STORY(`SELECT * FROM users WHERE _id='${data.viewerId}'`)

                // First check if the views is empty
                if (story.viewers == '' || story.viewers == null) {
                    let sql = `UPDATE story SET viewers='${users[0].id}' WHERE _id='${stories[0]._id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('1st views added')
                    })

                    return
                }

                let viewersArr = story.viewers.split(',')
                let newViewersArr = viewersArr.map(el => {
                    return parseInt(el)
                })

                let index = newViewersArr.indexOf(users[0].id)
                if (index < 0) {
                    newViewersArr.push(users[0].id)
                    console.log('add to viewers', newViewersArr)
                    let sql = `UPDATE story SET viewers='${newViewersArr}' WHERE _id='${stories[0]._id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                    })

                }

            } catch (error) {
                console.log(error)
            }
        })

        // Saving viewers id to story array ==================================
        socket.on('sendIdToSaveForViewers', async (data) => {
            // VIEWERS============================================
            async function STORY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const users = await STORY(`SELECT * FROM users WHERE _id='${data.userId}'`)
            const stories = await STORY(`SELECT * FROM story WHERE _id='${data.storyId}'`)
            let story = stories[0]
            // First check if the views is empty
            if (story.viewers == '' || story.viewers == null) {
                let sql = `UPDATE story SET viewers='${users[0].id}' WHERE _id='${data.storyId}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('1st views added')
                })

                return
            }

            let viewersArr = story.viewers.split(',')
            let newViewersArr = viewersArr.map(el => {
                return parseInt(el)
            })

            let index = newViewersArr.indexOf(users[0].id)
            if (index < 0) {
                newViewersArr.push(users[0].id)
                console.log('add to viewers', newViewersArr)
                let sql = `UPDATE story SET viewers='${newViewersArr}' WHERE _id='${data.storyId}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

            }


        })


        // =============================================================

        // fetching my story viewers 
        socket.on('fetchViewers', async (id) => {
            async function STORY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const stories = await STORY(`SELECT * FROM story WHERE _id='${id}'`)
            if (stories.length == 0) return

            let viewers = stories[0].viewers.split(',').map(val => parseInt(val))

            let fetchedUsers = []
            for (i = 0; i < viewers.length; i++) {
                const views = await STORY(`SELECT * FROM users WHERE id='${viewers[i]}'`)
                fetchedUsers.push(views)
            }

            let newViewsArr = []
            fetchedUsers.forEach(val => {
                val.forEach(cur => newViewsArr.push(cur))
            })

            let storyViewers = []
            newViewsArr.forEach(val => {
                val.password = undefined
                val.hasStory = undefined
                val.gender = undefined
                val.phoneNumber = undefined
                val.email = undefined
                val.bestSentence = undefined
                val.date = undefined
                val.genderDescription = undefined
                val.month = undefined
                val.month = undefined
                val.year = undefined
                val.activeStatus = undefined
                val.greenActive = undefined
                val.notifiicationLength = undefined
                val.createdAt = undefined
                val.token = undefined
                val.updatedAt = undefined
                val.hideWelcomeMsg = undefined
                val.chatNotification = undefined
                val.fullName = undefined
                storyViewers.push(val)
            })

            socket.emit('fetchedViewers', storyViewers)

        })
    })

    // story reaction
    io.on('connection', (socket) => {
        socket.on('storyReactionDetails', async (data) => {
            let userId = data.userId;
            let storyId = data.storyId;


            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
            const stories = await GETSQL(`SELECT * FROM story WHERE _id='${storyId}'`)
            let user = userx[0]
            let story = stories[0]

            // @ if post reaction is empty add the first value to it
            if (story.reaction == '' || story.reaction == null) {
                let sql = `UPDATE story SET reaction='${user.id}', reactionLength='${1}' WHERE id='${story.id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                return
            }

            const reaction = story.reaction.split(',')
            let newReaction = reaction.map(el => {
                return parseInt(el)
            })

            let index = newReaction.indexOf(user.id)

            // @ remove like
            if (index > -1) {
                newReaction.splice(index, 1)

                let sql = `UPDATE story SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE id='${story.id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                return
            }

            // @ add like
            newReaction.push(user.id)
            console.log(newReaction)
            let sql = `UPDATE story SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE id='${story.id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // console.log(user)


            // const storyId = await Story.findById(clientStoryId);
            // // const user = await User.findById(userId)
            // let arr = storyId.reaction;

            // let newArr = []
            // arr.forEach((cur) => {
            //     cur.forEach(value => {
            //         newArr.push(value)
            //     })
            // })

            // let index = newArr.indexOf(userId);
            // if (index > -1) {
            //     storyId.reaction.splice(index, 1)
            //     storyId.save()
            //     return

            // } else {
            //     storyId.reaction.push(userId)
            //     storyId.save()

            //     if (userId.toLocaleString() !== storyId.owner.toLocaleString()) {
            //         // Send notification    
            //         const notification = new Notification({
            //             owner: userId,
            //             text: 'Reacted to your storyId',
            //             comment: storyId.description,
            //             eventId: storyId._id,
            //             eventOwner: storyId.owner,
            //             date: fullDateStr,
            //             ownerName: `${user.firstname} ${user.lastname}`,
            //             urlLink: 'viewImagePostDetails/' + storyId._id
            //         })
            //         await notification.save()
            //         return
            //     }
            // }
        })

    })



    return router
}

