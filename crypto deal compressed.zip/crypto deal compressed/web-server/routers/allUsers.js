const router = require('express').Router();
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')


// Set created date
let monthsArray;
let month;
let newMonth;
let day = new Date().getDay();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = ` ${day} ${newMonth},  ${year}`


const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }

})


module.exports = function (io) {
    router.get('/allUsers', auth, async (req, res) => {

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = users[0]

        //@ Create suggestion fot user to follow____________________
        const allUsers = await User(`SELECT * FROM users`)
        let myFolloingArr = user.following + user.id
        let notFollowingIdsArray = []
        for (i = 0; i < allUsers.length; i++) {
            if (!myFolloingArr.includes(allUsers[i].id)) {
                notFollowingIdsArray.push(allUsers[i].id)
            }
        }

        let newUserTOFollow = []
        for (i = 0; i < notFollowingIdsArray.length; i++) {
            const fetchUsersToFollow = await User(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
            fetchUsersToFollow.forEach(val => {
                newUserTOFollow.push(val)
            })
        }

        newUserTOFollow = newUserTOFollow.splice(0, 4)
        newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
        // @_______________________________________________________

        // @ get four (4) post 
        let allPostsSuggestedPost = await User(`SELECT * FROM posts WHERE postType='image'`)
        allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
        allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)

        // get reaction
        let notification = await User(`SELECT * FROM notification WHERE eventOwner='${user._id}' ORDER BY id DESC`)

        res.render('allUsers', {
            user,
            users,
            allUsers: users,
            suggestedArr: newUserTOFollow,
            posts: allPostsSuggestedPost,
            notification,
            // chatNotification,
            // sentChatNotification,

        })
    })


    io.on('connection', (socket) => {
        socket.on('followingDetails', async (data) => {
            let id = data.followingId;
            let userId = data.userId
            // @ if user tries to follow himself
            if (id == userId) return console.log('Cant follow urseld')

            async function SQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await SQL(`SELECT * FROM users WHERE _id='${userId}'`)
            const user = userSQL[0]

            const user2Id = await SQL(`SELECT * FROM users WHERE _id='${id}'`)
            const user2 = user2Id[0]

            async function notificationFunction() {
                // Send notification    
                let randomId = crypto.randomBytes(12).toString('hex')
                const notification = {
                    owner: user._id,
                    _id: randomId,
                    text: 'Started following you',
                    eventOwner: data.followingId,
                    date: fullDateStr,
                    ownerName: `${user.firstname} ${user.lastname}`,
                    urlLink: 'profile/' + user._id,
                    readStatus: 'fa fa-question',
                    avatar: user.avatar
                }

                let sql = 'INSERT INTO notification SET ?'
                db.query(sql, notification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Created a new Nitification')
                })


                let findNotifcationOwner = await SQL(`SELECT * FROM users WHERE _id='${user2._id}'`)
                let eventOwner = findNotifcationOwner[0]
                if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                    let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${user2._id}'`
                    db.query(sql, (error) => {
                        if (error) return console.log(error)
                    })
                    return
                } else {
                    let count = parseInt(eventOwner.notifiicationLength)
                    count = count += 1
                    let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${user2._id}'`
                    db.query(sqlQueryForCOunt, (error) => {
                        if (error) return console.log(error)
                    })
                }

            }


            // check is the user follow is empty for user 2
            // @ if its empty add a new id to user 2 followier
            if (user2.follower == '' || user2.follower == null) {
                // Add user one follower to user 2 followers
                let sql = `UPDATE users SET follower='${user.id}', followerlength='${1}' WHERE _id='${user2._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('First follower added')

                    notificationFunction()
                })


                // Add user 2 id to user one following Increase user one following
                // /@ of the use following os empty run this
                if (user.following == '' || user.following == null) {
                    let sql = `UPDATE users SET following='${user2.id}', followingLength='${1}' WHERE _id='${user._id}'`
                    db.query(sql, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('First following added')
                    })
                    return
                }

                // If the user following is not empty
                let userArr = user.following.split(',')
                userArr.push(user2.id)
                let sqlcc = `UPDATE users SET following='${userArr}', followingLength='${userArr.length}' WHERE _id='${user._id}'`
                db.query(sqlcc, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('First following added')
                })


                return
            }

            // I

            let followerArray = user2.follower.split(',').map(val => parseInt(val))
            let index = followerArray.indexOf(user.id)

            if (index > -1) {
                // @ remove the user id from user 2 followrs 
                followerArray.splice(index, 1)
                let sqlxd = `UPDATE users SET follower='${followerArray}', followerlength='${followerArray.length}' WHERE _id='${user2._id}'`
                db.query(sqlxd, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Unfollowd user 2')
                })

                // remove user2 id from user1 following
                let followiingArray = user.following.split(',').map(val => parseInt(val)) || user2.id
                let indexOfFollowing = followiingArray.indexOf(user2.id)
                followiingArray.splice(indexOfFollowing, 1)

                let sqlgs = `UPDATE users SET following='${followiingArray}', followingLength='${followiingArray.length}' WHERE _id='${user._id}'`
                db.query(sqlgs, (error) => {
                    if (error) return console.log(error)
                    console.log('FRemoved user2 form following')
                })

                return
            }

            // Add my id to use 2 follower if I've not followed him before
            let followerArray2 = user2.follower.split(',').map(val => parseInt(val))
            followerArray2.push(user.id)

            let sqlquesry = `UPDATE users SET follower='${followerArray2}', followerlength='${followerArray2.length}' WHERE id='${user2.id}'`
            db.query(sqlquesry, (error) => {
                if (error) return console.log(error)
                console.log('newly followed user 2')
            })

            // Add the user2 id to my user1 following if I've not follwed him before
            // if user following is empty run the code below
            if (user.following == '' || user.following == null) {
                let sqlgs = `UPDATE users SET following='${user2.id}', followingLength='${1}' WHERE _id='${user._id}'`
                db.query(sqlgs, (error) => {
                    if (error) return console.log(error)
                    console.log('added user2 to following')
                })
                return
            }

            // if user following is not empty run the code below
            let followiingArray2Confition = user.following.split(',')
            followiingArray2Confition.push(user2.id)
            console.log(followiingArray2Confition)

            let sqlgs = `UPDATE users SET following='${followiingArray2Confition}', followingLength='${followiingArray2Confition.length}' WHERE id='${user.id}'`
            db.query(sqlgs, (error) => {
                if (error) {
                    return console.log(error)
                }
                console.log('added user2 to following')
                notificationFunction()
            })

        })
    })





    router.get('/allusers-api', auth, async (req, res) => {
        try {

            async function SQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const allUsers = await SQL(`SELECT * FROM users`)
            // const user = allUsers[0]

            allUser = allUsers.sort(() => Math.random() - 0.5)

            // remover binary data
            let newAllUsersArray = []
            allUsers.forEach(cur => {
                if (cur.bestSentence == null) {
                    cur.bestSentence = 'Plogapp user'
                }

                if (cur.followerLength == null) {
                    cur.followerLength = 0
                }

                cur.coverPhoto = undefined
                cur.storyImg = undefined
                cur.password = undefined
                cur.hasStory = undefined
                cur.gender = undefined
                cur.phoneNumber = undefined
                cur.email = undefined
                cur.date = undefined
                cur.genderDescription = undefined
                cur.month = undefined
                cur.month = undefined
                cur.year = undefined
                cur.activeStatus = undefined
                cur.greenActive = undefined
                cur.notifiicationLength = undefined
                cur.createdAt = undefined
                cur.token = undefined
                cur.updatedAt = undefined
                cur.hideWelcomeMsg = undefined
                cur.chatNotification = undefined
                newAllUsersArray.push(cur)
            })


            res.send(newAllUsersArray)

        } catch (error) {
            console.log('error')
        }
    })

    return router
}