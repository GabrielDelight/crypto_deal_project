const jwt = require('jsonwebtoken')
module.exports = async function (req, res, next) {
    try {
        const token = req.cookies.admin_token
        
        if (!token) {
            return res.redirect('/admin/login')
        }
        const verifyToken = await jwt.verify(token, 'thisfuckingsecretfuck')
        req.user = verifyToken
        next()
    } catch (error) {
        res.status(400).send("Invalid token")
        console.log('Invalid token')
        return
    }
}