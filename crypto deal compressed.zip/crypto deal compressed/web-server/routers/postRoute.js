const router = require('express').Router();
const multer = require('multer');
const auth = require('./auth')
const path = require('path');
const fs = require('fs')
const mysql = require('mysql');
const crypto = require('crypto')

// Set created date
let monthsArray;
let month;
let newMonth;
let day = new Date().getDate();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = ` ${day} ${newMonth},  ${year}`


// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/postImages',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})


const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})



db.connect((error) => {
    if (error) {
        console.log(error)
    }
})



module.exports = function (io) {

    router.post('/createPost', auth, upload.array('uploads', 5), async (req, res) => {
        try {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            // Generate random text
            const _id = crypto.randomBytes(12).toString('hex')

            let verify = user.verified
            
            if (req.body.checkPost == '') {
                let fullName = `${user.firstname} ${user.lastname}`
                const post = {
                    ...req.body,
                    _id,
                    date: fullDateStr,
                    postImageId: user._id,
                    possterName: fullName,
                    owner: user._id,
                    ownerPrimaryid: user.id,
                    posterNickName: user.fullName,
                    postType: 'text',
                    posterBio: user.bestSentence,
                    verified: verify,
                    hideLastComment: 'none',
                    avatar: user.avatar
                }

                let sql = 'INSERT INTO posts SET ?'
                db.query(sql, post, (error) => {
                    if (error) {
                        return console.log(error)
                    }

                    console.log('Post created')
                })

                res.redirect('/viewImagePostDetails/' + post._id)

            } else if (req.body.checkPost == 'image') {
                let len = 0;
                let hideSLides

                let fileId2 = '';
                let fileId3 = '';
                if (req.files.length === 1) {
                    fileId2 = ''
                    fileId3 = ''
                    hideSLides = 'none'
                    len = 1
                }
                else if (req.files.length === 2) {
                    fileId3 = ''
                    len = 2
                    fileId2 = req.files[1].filename
                }
                else if (req.files.length >= 3) {
                    len = 3
                    fileId2 = req.files[1].filename
                    fileId3 = req.files[2].filename
                }


                let fullName = `${user.firstname} ${user.lastname}`

                const post = {
                    ...req.body,
                    _id,
                    image: req.files[0].filename,
                    image1: fileId2,
                    image2: fileId3,
                    imageLength: len,
                    date: fullDateStr,
                    postImageId: user._id, //Use id to fetch image
                    possterName: fullName,
                    posterNickName: user.fullName,
                    hideSLides,
                    owner: user._id,
                    ownerPrimaryid: user.id,
                    postType: req.body.checkPost,
                    posterBio: user.bestSentence,
                    hideLastComment: 'none',
                    avatar: user.avatar,
                    verified: verify
                }

                let sql = 'INSERT INTO posts SET ?'
                db.query(sql, post, (error) => {
                    if (error) {
                        return console.log(error)
                    }

                    console.log('Post created')
                })
                res.redirect('/viewImagePostDetails/' + post._id)
            }
        } catch (error) {
            res.send(error)
            console.log('Error:' + error.message)
        }


    }, (error, req, res, next) => {
        res.send(error)
        res.redirect('/home')
    })



    // @ set up validation for image upload
    const videoStorage = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/postVideos',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const videoUpload = multer({
        // limits: 300000,
        storage: videoStorage
    })


    router.post('/videoUpload', videoUpload.single('uploads'), auth, async (req, res) => {
        try {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM users WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await User(req.user._id)
            let user = userx[0]

            // Generate random text
            const _id = crypto.randomBytes(12).toString('hex')

            let verify = user.verified

            // const user = await User.findById(req.user) //Get user to store unique id    
            let fullName = `${user.firstname} ${user.lastname}`
            const post = {
                ...req.body,
                _id,
                video: req.file.filename,
                date: fullDateStr,
                postImageId: user._id,
                possterName: fullName,
                owner: user._id,
                ownerPrimaryid: user.id,
                video: req.file.filename,
                postType: 'video',
                posterNickName: user.fullName,
                verified: verify,
                avatar: user.avatar,
                hideLastComment: 'none'
            }


            let sql = 'INSERT INTO posts SET ?'
            db.query(sql, post, (error) => {
                if (error) {
                    return console.log(error)
                }

                console.log('Post created')
            })
            res.redirect('/viewVideoPostDetails/' + post._id)

        } catch (error) {
            console.log(error.message)
            res.redirect('/home')
        }

    }, (error, req, res, next) => {
        res.redirect('/home')
    })



    // Edit post router
    router.post('/editPost', async (req, res) => {
        try {
            async function POST(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const textPost = await POST(`SELECT * FROM posts WHERE _id='${req.body.postId}'`)
            if(textPost.length > 0){
                
                let sql = `UPDATE posts SET description='${req.body.newDescription}' WHERE _id='${req.body.postId}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Updated edit post')
                })
                return res.redirect('/home')
            }

            let sql = `UPDATE sharepost SET description='${req.body.newDescription}' WHERE _id='${req.body.postId}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Updated share edit post')
            })

            return res.redirect('/home')

            

            
            return
        } catch (error) {
            console.log(error)
            console.log(req.body.postId)        
            res.redirect('/home')
        }

    })


    // Reaction on post
    io.on('connection', (socket) => {
        socket.on('reactionDetails', async (data) => {
            let userId = data.userId;
            let postId = data.postId;

            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
            const posts = await GETSQL(`SELECT * FROM posts WHERE _id='${postId}'`)
            let user = userx[0]
            let post = posts[0]

            // Function for reaction
            async function notificationFunction() {
                // set notifcation
                if (userId.toLocaleString() !== post.owner.toLocaleString()) {
                    let url = 'viewImagePostDetails/'
                    if (post.postType == 'video') url = 'viewVideoPostDetails/'

                    let randomId = crypto.randomBytes(12).toString('hex')

                    // Send notification    
                    const notification = {
                        owner: userId,
                        _id: randomId,
                        text: 'Reacted to your post',
                        comment: post.description,
                        eventId: post._id,
                        eventOwner: post.owner,
                        date: fullDateStr,
                        ownerName: `${user.firstname} ${user.lastname}`,
                        urlLink: url + post._id,
                        readStatus: 'fa fa-question',
                        avatar: user.avatar
                    }

                    let sql = 'INSERT INTO notification SET ?'
                    db.query(sql, notification, (error) => {
                        if (error) {
                            return console.log(error)
                        }
                        console.log('Created a new Nitification')
                    })


                    let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${post.owner}'`)
                    let eventOwner = findNotifcationOwner[0]
                    if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                        let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${post.owner}'`
                        db.query(sql, (error) => {
                            if (error) return console.log(error)
                        })
                        return
                    } else {
                        let count = parseInt(eventOwner.notifiicationLength)
                        count = count += 1
                        let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${post.owner}'`
                        db.query(sqlQueryForCOunt, (error) => {
                            if (error) return console.log(error)
                        })
                    }
                }
            }



            // @ if post reaction is empty add the first value to it
            if (post.reaction == '' || post.reaction == null) {
                let sql = `UPDATE posts SET reaction='${user.id}', reactionLength='${1}' WHERE _id='${post._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                notificationFunction()

                return
            }

            const reaction = post.reaction.split(',')
            let newReaction = reaction.map(el => {
                return parseInt(el)
            })

            let index = newReaction.indexOf(user.id)

            // @ remove like
            if (index > -1) {
                console.log('remove')
                newReaction.splice(index, 1)

                let sql = `UPDATE posts SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${post._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                return
            }

            // @ add like
            newReaction.push(user.id)
            let sql = `UPDATE posts SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${post._id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            notificationFunction()

        })

    })




    // Reactions in comments ********************************
    io.on('connection', (socket) => {
        socket.on('commentLikeDetails', async (data) => {

            let userId = data.ownerId;
            let commentId = data.commentId

            async function GETSQL(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await GETSQL(`SELECT * FROM users WHERE _id='${userId}'`)
            const comments = await GETSQL(`SELECT * FROM comments WHERE _id='${commentId}'`)
            let user = userx[0]
            let comment = comments[0]

            // Notification ****************
            async function notificationFunction() {
                try {
                    // Send notification    
                    const findPostOwner = await GETSQL(`SELECT * FROM posts WHERE _id='${comment.postId}'`)
                    let findPost = findPostOwner[0]
                    let postLink = 'viewImagePostDetails/'
                    if (findPost.postType == 'video') {
                        postLink = 'viewVideoPostDetails/'
                    }

                    let randomId = crypto.randomBytes(12).toString('hex')
                    if (userId.toString() != comment.owner.toString()) {
                        const notification = {
                            owner: userId,
                            _id: randomId,
                            text: 'Reacted to your comment',
                            comment: comment.comment,
                            eventId: comment._id,
                            eventOwner: comment.owner,
                            date: fullDateStr,
                            ownerName: `${user.firstname} ${user.lastname}`,
                            urlLink: postLink + comment.postId,
                            readStatus: 'fa fa-question',
                            avatar: user.avatar
                        }

                        let sql = 'INSERT INTO notification SET ?'
                        db.query(sql, notification, (error) => {
                            if (error) {
                                return console.log(error)
                            }
                            console.log('Created a new Nitification')
                        })

                        let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${comment.owner}'`)
                        let eventOwner = findNotifcationOwner[0]
                        if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                            let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${comment.owner}'`
                            db.query(sql, (error) => {
                                if (error) return console.log(error)
                            })
                            return
                        } else {
                            let count = parseInt(eventOwner.notifiicationLength)
                            count = count += 1
                            let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${comment.owner}'`
                            db.query(sqlQueryForCOunt, (error) => {
                                if (error) return console.log(error)
                            })
                        }

                        return
                    }

                } catch (error) {
                    const findPosts = await GETSQL(`SELECT * FROM sharepost WHERE _id='${comment.postId}'`)
                    let findPost = findPosts[0]
                    let postLink = ''
                    if (findPost.postType == 'text' || findPost.postType == 'photo') postLink = 'shareLink/' + comment.postId
                    else if (findPost.postType == 'video') postLink = 'sharedLinkVideo/' + comment.postId

                    let randomId = crypto.randomBytes(12).toString('hex')
                    if (userId.toString() != comment.owner.toString()) {
                        const notification = {
                            owner: userId,
                            _id: randomId,
                            text: 'Reacted to your comment',
                            comment: comment.comment,
                            eventId: comment._id,
                            eventOwner: comment.owner,
                            date: fullDateStr,
                            ownerName: `${user.firstname} ${user.lastname}`,
                            urlLink: postLink,
                            readStatus: 'fa fa-question',
                            avatar: user.avatar
                        }

                        let sql = 'INSERT INTO notification SET ?'
                        db.query(sql, notification, (error) => {
                            if (error) {
                                return console.log(error)
                            }
                        })

                        let findNotifcationOwner = await GETSQL(`SELECT * FROM users WHERE _id='${comment.owner}'`)
                        let eventOwner = findNotifcationOwner[0]
                        if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                            let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${comment.owner}'`
                            db.query(sql, (error) => {
                                if (error) return console.log(error)
                                console.log('Notification added1')
                            })
                            return
                        } else {
                            let count = parseInt(eventOwner.notifiicationLength)
                            count = count += 1
                            let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${comment.owner}'`
                            db.query(sqlQueryForCOunt, (error) => {
                                if (error) return console.log(error)
                                console.log('Notification added2')
                            })
                        }
                    }
                }

            }


            // @ if post reaction is empty add the first value to it
            if (comment.reaction == '' || comment.reaction == null) {
                let sql = `UPDATE comments SET reaction='${user.id}', reactionLength='${1}' WHERE _id='${comment._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                notificationFunction()
                return
            }

            const reaction = comment.reaction.split(',')
            let newReaction = reaction.map(el => {
                return parseInt(el)
            })

            let index = newReaction.indexOf(user.id)

            // @ remove like
            if (index > -1) {
                newReaction.splice(index, 1)

                let sql = `UPDATE comments SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${comment._id}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                return
            }

            // @ add like
            newReaction.push(user.id)
            let sql = `UPDATE comments SET reaction='${newReaction}', reactionLength='${newReaction.length}' WHERE _id='${comment._id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
            notificationFunction()
        })



        // @ getting replies from db ************************************************
        socket.on('commentId', async (id) => {
            try {
                // const replies = await Reply.find({ mainCommentId: id })

                async function SQL(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }

                const replies = await SQL(`SELECT * FROM replies WHERE mainCommentId='${id}'`)
                if(replies.length < 1) return

                socket.emit('fetchedReplies', {
                    replies,
                    replyLength: replies.length,
                    commentId: id
                })

            } catch (error) {
                console.log('Error')
            }
        })

        // fetch users for mention
        socket.on('fetchFollowersForMention', async id => {
            try {

                async function SQLQUERRY(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }

                const findYsers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${id}'`)
                let user = findYsers[0]

                let getFollowing = user.following.split(',');

                // loop to get the iser
                let newFollowersArr = []
                for (i = 0; i < getFollowing.length; i++) {
                    const user = await SQLQUERRY(`SELECT * FROM users WHERE id='${getFollowing[i]}'`)
                    
                    user.forEach(cur => {
                        newFollowersArr.push(cur)

                    })
                    
                }
                // try and remove heavey data 
                let myFinalFollowes = []
                newFollowersArr.forEach(val => {
                    val.coverPhoto = undefined
                    val.storyImg = undefined
                    val.password = undefined
                    val.hasStory = undefined
                    val.gender = undefined
                    val.phoneNumber = undefined
                    val.email = undefined
                    val.bestSentence = undefined
                    val.date = undefined
                    val.genderDescription = undefined
                    val.month = undefined
                    val.month = undefined
                    val.year = undefined
                    val.activeStatus = undefined
                    val.greenActive = undefined
                    val.notifiicationLength = undefined
                    val.createdAt = undefined
                    val.token = undefined
                    val.updatedAt = undefined
                    val.hideWelcomeMsg = undefined
                    val.chatNotification = undefined
                    myFinalFollowes.push(val)
                })

                socket.emit('readyToMentionUsers', {
                    fetchedMentioned: myFinalFollowes,
                    id
                })

            } catch (err) {
                console.log('Error', err)
            }
        })


        socket.on('mentionInput', async data => {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            const Allusers = await SQLQUERRY(`SELECT * FROM users`)
            const curUser = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.userId}'`)
            let user = curUser[0]

            // get all the usernames @
            let arrofnames = []
            for(i = 0; i < Allusers.length; i++){
                if(Allusers[i].fullName.includes(data.text)){
                    arrofnames.push(Allusers[i].fullName)
                }
            }

            // get all the users that matched
            let foundUsersArray = []
            for(i = 0; i < arrofnames.length; i++){
                const foundUsers = await SQLQUERRY(`SELECT * FROM users WHERE fullName='${arrofnames[i]}'`)
                foundUsers.forEach(val => {
                    foundUsersArray.push(val)
                })
            }

            // console.log(foundUsersArray)
            socket.emit('readyToMentionUsers', {
                fetchedMentioned: foundUsersArray,
                id: user._id
            })
            




        
        })

    })

    // update post bio
    async function myFUnction(req, res, next) {
        try {
            const post = await Post.find()
            for (i = 0; i < post.length; i++) {
                let user = await User.findById(post[i].owner)
                let userBio = user.bestSentence
                if (userBio == '') {
                    userBio = 'User'
                }
                post[i].posterBio = userBio
                post[i].posterFollower = user.follower.length
                post[i].posterFollowing = user.following.length
                post[i].posterNickName = user.fullName
                // post[i].posertFollowing = []
                await post[i].save()
            }
        } catch (error) {

        }

    }

    // myFUnction()
    setInterval(myFUnction, 1500)




    router.get('/deletePost/:id', async (req, res) => {
        try {
            // let post = await Post.findById(req.params.id);

            async function POST(val) {
                return new Promise((resolve, reject) => {
                    let sql = `SELECT * FROM posts WHERE _id='${val}'`
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const posts = await POST(req.params.id)
            let post = posts[0]
            console.log(post)


            if (post.postType == 'text') {
                let sql = `DELETE FROM posts WHERE _id='${req.params.id}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Deleted successful')
                })
                return res.redirect('/home')
            }


            if (post.postType == 'video') {
                let sql = `DELETE  FROM posts WHERE _id='${req.params.id}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Deleted successful')
                })

                fs.unlink('./web-server/web-folder/public/webStorage/postVideos/' + post.video, (error) => {
                    if (!error) {
                        console.log('Deleted video')
                    }
                })

                res.redirect('/home')


            }


            if (post.imageLength == 1 && post.postType == 'image') {

                let sql = `DELETE  FROM posts WHERE _id='${req.params.id}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Deleted successful')
                })

                fs.unlink('./web-server/web-folder/public/webStorage/postImages/' + post.image, (error) => {
                    if (!error) {
                        console.log('Deleted images')
                    }
                })
                return res.redirect('/home')
            }


            if (post.imageLength == 2 && post.postType == 'image') {
                let sql = `DELETE  FROM posts WHERE _id='${req.params.id}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Deleted successful')
                })


                fs.unlink('./web-server/web-folder/public/webStorage/postImages/' + post.image, (error) => {
                    if (!error) {
                        console.log('Deleted images')
                    }
                })

                fs.unlink('./web-server/web-folder/public/webStorage/postImages/' + post.image1, (error) => {
                    if (!error) {
                        console.log('Deleted images1')
                    }
                })

                return res.redirect('/home')
            }


            if (post.imageLength == 3 && post.postType == 'image') {
                let sql = `DELETE  FROM posts WHERE _id='${req.params.id}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    console.log('Deleted successful')
                })


                // delete the gfs modal
                fs.unlink('./web-server/web-folder/public/webStorage/postImages/' + post.image, (error) => {
                    if (!error) {
                        console.log('Deleted images')
                    }
                })

                fs.unlink('./web-server/web-folder/public/webStorage/postImages/' + post.image1, (error) => {
                    if (!error) {
                        console.log('Deleted images1')
                    }
                })

                fs.unlink('./web-server/web-folder/public/webStorage/postImages/' + post.image2, (error) => {
                    if (!error) {
                        console.log('Deleted images1')
                    }
                })

                return res.redirect('/home')
            }
            res.redirect('/home')

        } catch (error) {
            console.log(error)
            res.redirect('/home')
        }

    })





    return router
}

