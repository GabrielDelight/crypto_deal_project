const router = require('express').Router()
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }
})


module.exports = function (io) {

    // mark all as read
    router.get('/markAllAsRead', auth, async (req, res) => {
        let sql = `UPDATE notification SET readStatus='fa fa-check',readStatusColor='#bdbdbd' WHERE eventOwner='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })
        res.redirect('/home')
    })

    // Delete notification
    router.get('/deleteNotification', auth, async (req, res) => {
        let sql = `DELETE FROM notification WHERE eventOwner='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })
        res.redirect('/home')
    })


    io.on('connection', (socket) => {
        // When a user clicks on notification change it to read
        socket.on('notificationId', async (data) => {
            let sql = `UPDATE notification SET readStatus='fa fa-check',readStatusColor='#bdbdbd' WHERE _id='${data}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
        })

        // Get all notification to show the counter or numbers in header bell icon
        // socket.on('userNotificationId', async (data) => {
        //     const notification = await Notification.find({ eventOwner: data })
        //     const user = await User.findById(data)
        //     let countArr = [0]
        //     for (i = 0; i < notification.length; i++) {
        //         countArr.push(notification[i].count)
        //     }
        //     let totalNotification = countArr.reduce((a, b) => a + b)
        //     if (totalNotification == 0) {
        //         totalNotification = ''
        //     }
        //     user.notifiicationLength = totalNotification

        //     await user.save()
        // })

        // Deleting a single notification
        socket.on('deleteSingleNotification', async data => {
            try {
                let sql = `DELETE FROM notification WHERE _id='${data}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

            } catch (error) {
                console.log(error.message)
            }
        })

        // remove the notification number
        socket.on('removebnotNumber', async (data) => {
            let sql = `UPDATE users SET notifiicationLength='' WHERE _id='${data}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

        })

    })
    return router
}