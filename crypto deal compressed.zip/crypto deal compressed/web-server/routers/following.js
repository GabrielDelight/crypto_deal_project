const router = require('express').Router();
// const User = require('../models/model')
const Post = require('../models/postModel')
const auth = require('./auth')
const mysql = require('mysql');
const crypto = require('crypto')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }
})

module.exports = function (io) {
    let publickParams = []
    router.get('/following/:id', auth, async (req, res) => {

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        let users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let user = users[0]
        
        let pareamsFollowers = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        pareamsFollowers = pareamsFollowers[0]
        let following = pareamsFollowers.following.split(',')

        // @ get user following
        let newFollowingsArr = []
        for (i = 0; i < following.length; i++) {
            const findusers = await User(`SELECT * FROM users WHERE id='${following[i]}'`)
            findusers.forEach(val => {
                newFollowingsArr.push(val)
            })
        }

        const followingOwner = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)

        //@ Create suggestion fot user to follow____________________
        const allUsers = await User(`SELECT * FROM users`)
        let myFolloingArr = user.following + user.id
        let notFollowingIdsArray = []
        for (i = 0; i < allUsers.length; i++) {
            if (!myFolloingArr.includes(allUsers[i].id)) {
                notFollowingIdsArray.push(allUsers[i].id)
            }
        }

        let newUserTOFollow = []
        for (i = 0; i < notFollowingIdsArray.length; i++) {
            const fetchUsersToFollow = await User(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
            fetchUsersToFollow.forEach(val => {
                newUserTOFollow.push(val)
            })
        }

        newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
        newUserTOFollow = newUserTOFollow.splice(0, 4)
        // @_______________________________________________________

        // @ get four (4) post 
        let allPostsSuggestedPost = await User(`SELECT * FROM posts WHERE postType='image'`)
        allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
        allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)

        // get reaction
        let notification = await User(`SELECT * FROM notification WHERE eventOwner='${user._id}' ORDER BY id DESC`)

        res.render('following', {
            user,
            followingUsers: newFollowingsArr,
            followingOwner: followingOwner[0],
            suggestedArr: newUserTOFollow,
            posts: allPostsSuggestedPost,
            notification,
            // users,
            // chatNotification,
            // title: followingOwner.firstname,
            // sentChatNotification,
        })
    })


    //     io.on('connection', (socket) => {
    //         socket.on('sendUserIdToGetFollowing', async (xId) => {
    //             const getFollowing = await User.findById(xId)

    //         // let followingUsers
    //         let ids = getFollowing.following
    //         let idsArr = []
    //         ids.forEach(cur => {
    //             cur.forEach(val => {
    //                 idsArr.push(val) //Push to idsArr
    //             })
    //         })


    //         let jsonArr = []
    //         for(i = 0; i < idsArr.length;i++){
    //             let followingUsers=  await User.findById(idsArr[i])
    //             jsonArr.push(followingUsers)
    //         }        


    //         let newFollowingArray = []
    //         jsonArr.forEach(cur => {
    //             cur.storyImg = undefined
    //             cur.password = undefined
    //             cur.hasStory = undefined
    //             cur.gender = undefined
    //             cur.phoneNumber = undefined
    //             cur.email = undefined
    //             cur.date = undefined
    //             cur.genderDescription = undefined
    //             cur.month = undefined
    //             cur.month = undefined
    //             cur.year = undefined
    //             cur.activeStatus = undefined
    //             cur.greenActive = undefined
    //             cur.notifiicationLength = undefined
    //             cur.createdAt = undefined
    //             cur.token = undefined
    //             cur.updatedAt = undefined
    //             cur.hideWelcomeMsg = undefined
    //             cur.chatNotification = undefined
    //             cur.fullName = undefined

    //             newFollowingArray.push(cur)
    //         })

    //         // let shuffledFollowing = newFollowingArray.sort(() => Math.random() - 0.5)
    //         socket.emit('following-socket', newFollowingArray)
    //         })
    //     })


    //     router.get('/following-api', auth, async (req, res) => {
    //         let newParamsId = publickParams[publickParams.length -1]
    //         let xId = newParamsId.toString()
    //         const getFollowing = await User.findById(xId)

    //         // let followingUsers
    //         let ids = getFollowing.following
    //         let idsArr = []
    //         ids.forEach(cur => {
    //             cur.forEach(val => {
    //                 idsArr.push(val) //Push to idsArr
    //             })
    //         })

    //         let followingUsers = ''
    //         let jsonArr = []
    //         for(i = 0; i < idsArr.length;i++){
    //             followingUsers=  await User.findById(idsArr[i])
    //             jsonArr.push(followingUsers)
    //         }        


    //         let newFollowingArray = []
    //         jsonArr.forEach(cur => {
    //             cur.avatar = undefined
    //             cur.coverPhoto = undefined
    //             cur.storyImg = undefined            

    //             newFollowingArray.push(cur)
    //         })

    //         let shuffledFollowing = newFollowingArray.sort(() => Math.random() - 0.5)
    //         res.send(shuffledFollowing)
    //         publickParams = []

    //     })


    return router
}

