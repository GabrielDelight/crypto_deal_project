const router = require('express').Router();
const User = require('../models/model');
const auth = require('./auth')
const multer = require('multer')
const path = require('path');
const fs = require('fs')
const mysql = require('mysql');
const crypto = require('crypto')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})



db.connect((error) => {
    if (error) {
        console.log(error)
    }
    
})


module.exports = function (io) {
    router.get('/chat/:id', auth, async (req, res) => {
        async function SQLQUERRY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let user = userx[0]

        const findUser2 = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        let user2 = findUser2[0]


        // const myChat = await Chatsender.find({ owner: user._id, receiverId: req.params.id })
        // const otherChat = await ChatReceiver.find({ receiverId: user._id, owner: req.params.id })
        const otherChat = await SQLQUERRY(`SELECT * FROM chatreceiver WHERE receiverId='${user._id}' AND owner='${req.params.id}'`)
        const myChat = await SQLQUERRY(`SELECT * FROM chatsender WHERE owner='${user._id}' AND receiverId='${req.params.id}'`)
        let allChat = myChat.concat(otherChat)
        // console.log(myChat.length)
        // console.log(otherChat.length)
        let messages = allChat.sort((a, b) => {
            let c = new Date(a._id)
            let d = new Date(b._id)
            return c - d
        })


        let chatNotification = await SQLQUERRY(`SELECT * FROM chatnotification WHERE receiverId='${user._id}' ORDER BY id DESC`)
    
        let sentChatNotification = await SQLQUERRY(`SELECT * FROM sentchatnotification WHERE owner='${user._id}' ORDER BY id DESC`)
        

        res.render('chat', {
            user,
            chatFriend: user2,
            messages,
            // users,
            // followers: lastFollArr,
            // groupChat,
            // chatImages,
            chatNotification,
            sentChatNotification
            // unReadLength: unReadLength.length
        })

    })

    // Workng with real time in socket io for the chat **********************************
    io.on('connection', (socket) => {
        // Save chat to send to recipient and not appending to user that sent
        socket.on('saveChat', async (data) => {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.owner}'`)
            let user = userx[0]

            if (data.replyOldMessage == '') {

                //Send immediately to the browser
                // const user = await User.findById(data.owner)
                let newData = {
                    ...data,
                    avatar: user.avatar
                }

                socket.broadcast.emit('displayMessage', newData)


                const chatReceiver = {
                    ...data,
                    _id: new Date(),
                    ownerName: user.firstname + ' ' + user.lastname,
                    pushChat: 'pushLeft',
                    hide: 'none',
                    hideOldReply: 'none',
                    hideVideo: 'none',
                    chatType: 'text',
                    hideAudio: 'none',
                    hideStory: 'none',
                    count: 1
                }

                let sql = 'INSERT INTO chatreceiver SET ?'
                db.query(sql, chatReceiver, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Send notification by adding "+1" to user details
                let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${data.receiverId}'`
                db.query(sqlForUser, (error) => {
                    if (error) return console.log(error)
                })

                // send quick notification to all header icons
                socket.broadcast.emit('newMsg', 'New')

            } else {
                //Send immediately to the browser
                socket.broadcast.emit('displayMessage', data)

                let randomId = crypto.randomBytes(12).toString('hex')

                // const user = await User.findById(data.owner)
                const ChatReceiver = {
                    ...data,
                    _id: new Date(),
                    ownerName: user.firstname + ' ' + user.lastname,
                    pushChat: 'replyPushLeft',
                    hide: 'none',
                    hideVideo: 'none',
                    hideOldReply: 'block',
                    chatType: 'text',
                    hideAudio: 'none',
                    hideStory: 'none',
                    count: 1
                }

                let sql = 'INSERT INTO chatreceiver SET ?'
                db.query(sql, ChatReceiver, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Send notification by adding "+1" to user details
                let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${data.receiverId}'`
                db.query(sqlForUser, (error) => {
                    if (error) return console.log(error)
                })

                // send quick notification to all header icons
                socket.broadcast.emit('newMsg', 'New')
            }


        })


        // Save chat to append to user that sent it ******************
        socket.on('myChat', async (data) => {

            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.owner}'`)
            let user = userx[0]

            if (data.replyOldMessage == '') {
                let randomId = crypto.randomBytes(12).toString('hex')
                const Chatsender = {
                    ...data,
                    _id: new Date(),
                    ownerName: user.firstname + ' ' + user.lastname,
                    pushChat: 'pushRight',
                    hide: 'none',
                    hideOldReply: 'none',
                    chatType: 'text',
                    hideVideo: 'none',
                    hideAudio: 'none',
                    hideStory: 'none',
                }


                let sql1 = 'INSERT INTO chatsender SET ?'
                db.query(sql1, Chatsender, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                //Chat notification  **********************************************************************

                // Deleting my old send messages
                let sql = `DELETE FROM sentchatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                const chatReeivers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.receiverId}'`)
                let chatReeiver = chatReeivers[0]

                let randomId2 = crypto.randomBytes(12).toString('hex')

                const sentChatNotification = {
                    _id: randomId2,
                    owner: data.owner,
                    ownerName: data.ownerName,
                    receiverName: data.receiverName,
                    message: data.message,
                    date: data.date,
                    receiverId: data.receiverId,
                    avatar: chatReeiver.avatar,
                }

                let sql2 = 'INSERT INTO sentchatnotification SET ?'
                db.query(sql2, sentChatNotification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Deleteing old notification so it wont  dublicate
                let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND ownerName='${data.ownerName}'`
                db.query(sql3, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                let randomId3 = crypto.randomBytes(12).toString('hex')
                // Save the chat notification
                const chatNotification = {
                    _id: randomId3,
                    ...data,
                    lastChat: data.message,
                    avatar: user.avatar,
                    ownerName: user.firstname + ' ' + user.lastname
                }
                delete chatNotification.replyOldMessage

                let sql4 = 'INSERT INTO chatnotification SET ?'
                db.query(sql4, chatNotification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                // appending chat notification 
                let updateMsgData = {
                    ...data,
                    avatar: user.avatar
                }
                io.emit('updateMessage', {
                    ...updateMsgData,
                    _id: chatNotification._id
                })

            } else {

                // Chat sending ==============================================

                const Chatsender = {
                    ...data,
                    _id: new Date(),
                    ownerName: user.firstname + ' ' + user.lastname,
                    pushChat: 'replyPushRight',
                    hide: 'none',
                    hideVideo: 'none',
                    chatType: 'text',
                    hideOldReply: 'block',
                    hideAudio: 'none',
                    hideStory: 'none',
                }

                let sql5 = 'INSERT INTO chatsender SET ?'
                db.query(sql5, Chatsender, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })



                //Chat notification  **********************************************************************
                // Deleting my old send messages
                let sql6 = `DELETE FROM sentchatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
                db.query(sql6, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                const chatReeivers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.receiverId}'`)
                let chatReeiver = chatReeivers[0]

                let randomId2 = crypto.randomBytes(12).toString('hex')

                const sentChatNotification = {
                    owner: data.owner,
                    _id: randomId2,
                    ownerName: data.ownerName,
                    receiverName: data.receiverName,
                    message: data.message,
                    date: data.date,
                    avatar: chatReeiver.avatar,
                    receiverId: data.receiverId
                }

                let sql2 = 'INSERT INTO sentchatnotification SET ?'
                db.query(sql2, sentChatNotification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // Deleteing old notification so it wont  dublicate
                let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND ownerName='${data.ownerName}'`
                db.query(sql3, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                })

                // Save the chat notification
                let randomId3 = crypto.randomBytes(12).toString('hex')
                const chatNotification = {
                    _id: randomId3,
                    ...data,
                    lastChat: data.message,
                    avatar: user.avatar,
                    ownerName: user.firstname + ' ' + user.lastname
                }
                delete chatNotification.replyOldMessage

                let sql4 = 'INSERT INTO chatnotification SET ?'
                db.query(sql4, chatNotification, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })


                // appending chat notification 
                io.emit('updateMessage', {
                    ...data,
                    _id: chatNotification._id
                })

                // If i type over rie the notification message

                try {
                    const otherNotify = await SQLQUERRY(`SELECT * FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`)
                    if (!otherNotify.length === 0) {
                        return
                    }

                    let sql = `UPDATE chatnotification SET lastChat='${data.message}' WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
                    db.query(sql, (error) => {
                        if (error) return console.log(error)
                    })


                } catch (error) {
                    console.log(error)
                }
            }

        })


        // Send typing to client browser ***********
        socket.on('sendTyping', (data) => {
            socket.broadcast.emit('showTyping', data)
        })

        socket.on('sendHideTyping', (data) => {
            socket.broadcast.emit('showHideTyping', data)
        })
        // ========================



        // Story selection for Story receiver
        socket.on('storyReceiver', async (data) => {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.owner}'`)
            let user = userx[0]

            const ChatReceiver = {
                ...data,
                _id: new Date(),
                ownerName: user.firstname + ' ' + user.lastname,
                storyImageUrl: data.storyImageUrl,
                pushChat: 'pushStoryLeft',
                hide: 'none',
                hideOldReply: 'none',
                chatType: 'text',
                hideVideo: 'none',
                hideAudio: 'none',
                hideStory: 'block'
            }


            let sql = 'INSERT INTO chatreceiver SET ?'
            db.query(sql, ChatReceiver, (error) => {
                if (error) {
                    return console.log(error)
                }
            })



            // =====================
            //Chat notification  **********************************************************************
            // Deleting my old send messages
            let sql6 = `DELETE FROM sentchatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
            db.query(sql6, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })

            // await SentChatNotification.deleteMany({ owner: data.owner, receiverId: data.receiverId })
            const chatReeivers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.receiverId}'`)
            let chatReeiver = chatReeivers[0]
            let randomId2 = crypto.randomBytes(12).toString('hex')
            const sentChatNotification = {
                owner: data.owner,
                _id: randomId2,
                ownerName: data.ownerName,
                receiverName: data.receiverName,
                message: 'You replied to a story',
                date: data.date,
                avatar: chatReeiver.avatar,
                receiverId: data.receiverId
            }


            let sql2 = 'INSERT INTO sentchatnotification SET ?'
            db.query(sql2, sentChatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Send notification by adding "+1" to user details
            let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${data.receiverId}'`
            db.query(sqlForUser, (error) => {
                if (error) return console.log(error)
            })


            // Deleteing old notification so it wont  dublicate
            let sql3 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND ownerName='${data.ownerName}'`
            db.query(sql3, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })

            // Save the chat notification
            let randomId3 = crypto.randomBytes(12).toString('hex')
            const chatNotification = {
                ...data,
                _id: randomId3,
                lastChat: 'Replid to your story',
                avatar: user.avatar,
                ownerName: user.firstname + ' ' + user.lastname
            }

            // Delete this invalid property
            delete chatNotification.storyImageUrl
            delete chatNotification.replyOldMessage


            let sql4 = 'INSERT INTO chatnotification SET ?'
            db.query(sql4, chatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // If i type over rie the notification message

            try {
                const otherNotify = await SQLQUERRY(`SELECT * FROM chatnotification WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`)
                if (!otherNotify.length === 0) {
                    return
                }

                let sql = `UPDATE chatnotification SET lastChat='${data.message}' WHERE owner='${data.receiverId}' AND receiverId='${data.owner}'`
                db.query(sql, (error) => {
                    if (error) return console.log(error)
                })

            } catch (error) {
                console.log(error.message)
            }


        })


        // Message for Chat owner sending chat
        socket.on('storyOwner', async (data) => {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.owner}'`)
            let user = userx[0]

            const Chatsender = {
                ...data,
                _id: new Date(),
                storyImageUrl: data.storyImageUrl,
                ownerName: user.firstname + ' ' + user.lastname,
                pushChat: 'pushStoryRight',
                hide: 'none',
                hideOldReply: 'none',
                chatType: 'text',
                hideVideo: 'none',
                hideAudio: 'none',
                hideStory: 'block',
            }

            let sql4 = 'INSERT INTO chatsender SET ?'
            db.query(sql4, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

        })


    })



    let arrayOfDetails = []
    io.on('connection', (socket) => {
        socket.on('imageDetails', (data) => {
            arrayOfDetails.push(data)
        })

    })

    // @ set up validation for image upload
    const storageForChatImages = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/chatImages',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const uploadForChatImages = multer({
        // limits: 300000,
        storage: storageForChatImages
    })


    router.post('/chatImageUpload/:id', auth, uploadForChatImages.single('uploads'), async (req, res) => {
        try {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            // const user = await User.findById(req.user)
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            // const sencondUser = await User.findById(req.params.id)
            const sencondUsers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            let sencondUser = sencondUsers[0]

            let data = {
                owner: user._id,
                ownerName: user.firstname + ' ' + user.lastname,
                receiverId: req.params.id,
                receiverName: sencondUser.firstname + ' ' + sencondUser.lastname,
            }


            const Chatsender = {
                ...data,
                _id: new Date(),
                message: req.body.message,
                image: req.file.filename,
                pushChat: 'pushImgRight',
                chatType: 'image',
                hide: 'block',
                hideVideo: 'none',
                hideChatText: 'none',
                hideAudio: 'none',
                hideStory: 'none',
            }

            let sql = 'INSERT INTO chatsender SET ?'
            db.query(sql, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })



            const ChatReceiver = {
                ...data,
                _id: new Date(),
                image: req.file.filename,
                pushChat: 'pushImgLeft',
                chatType: 'image',
                message: req.body.message,
                hide: 'block',
                hideChatText: 'none',
                hideVideo: 'none',
                hideAudio: 'none',
                hideStory: 'none',
            }

            let sql2 = 'INSERT INTO chatreceiver SET ?'
            db.query(sql2, ChatReceiver, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Send notification by adding "+1" to user details
            let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${sencondUser._id}'`
            db.query(sqlForUser, (error) => {
                if (error) return console.log(error)
            })



            // Deleteing old notification so it wont  dublicate
            let sql6 = `DELETE FROM sentchatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
            db.query(sql6, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })


            // let chatReeiver = await User.findById(data.receiverId)
            const chatReeivers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.receiverId}'`)
            let chatReeiver = chatReeivers[0]

            let randomId2 = crypto.randomBytes(12).toString('hex')
            const sentChatNotification = {
                _id: randomId2,
                owner: data.owner,
                ownerName: data.ownerName,
                receiverName: chatReeiver.firstname + ' ' + chatReeiver.lastname,
                message: 'you Sent a photo',
                date: data.date,
                avatar: chatReeiver.avatar,
                receiverId: data.receiverId
            }


            let sql3 = 'INSERT INTO sentchatnotification SET ?'
            db.query(sql3, sentChatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Deleteing old notification so it wont  dublicate
            let sql4 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND ownerName='${data.ownerName}'`
            db.query(sql4, (error, result) => { if (error) return console.log(error) })

            // Save the chat notification
            let randomId3 = crypto.randomBytes(12).toString('hex')
            const chatNotification = {
                ...data,
                _id: randomId3,
                lastChat: 'Sent a photo',
                avatar: user.avatar,
                ownerName: user.firstname + ' ' + user.lastname
            }

            // Delete this invalid property

            let sql5 = 'INSERT INTO chatnotification SET ?'
            db.query(sql5, chatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            res.redirect('/chat/' + data.receiverId)
        }
        catch (error) {
            console.log(error.message)
            res.redirect('/chat/' + req.params.id)
        }

    }, async (error, req, res, next) => {
        console.log(error)
        res.redirect('/chat/' + req.params.id)
    })


    // send image immdiately
    io.on('connection', (socket) => {
        socket.on('imageSrc', (data) => {
            console.log(socket)
            socket.broadcast.emit('showImg', data)
        })
    })





    // Video upload ******************************************
    // @ set up validation for image upload
    const storageForChatVideos = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/chatVideos',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const uploadForChatVideos = multer({
        // limits: 300000,
        storage: storageForChatVideos
    })

    router.post('/videoChatUpload/:id', auth, uploadForChatVideos.single('uploads'), async (req, res) => {
        try {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }

            // const user = await User.findById(req.user)
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            // const sencondUser = await User.findById(req.params.id)
            const sencondUsers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            let sencondUser = sencondUsers[0]

            // const user = await User.findById(req.user)
            // const sencondUser = await User.findById(req.params.id)

            let data = {
                owner: user._id,
                ownerName: user.firstname + ' ' + user.lastname,
                receiverId: req.params.id,
                receiverName: sencondUser.firstname + ' ' + sencondUser.lastname,
            }

            const Chatsender = {
                ...data,
                _id: new Date(),
                video: req.file.filename,
                pushChat: 'pushVideoRight',
                chatType: 'video',
                hide: 'none',
                hideVideo: 'block',
                hideAudio: 'none',
                hideStory: 'none',
            }

            let sql = 'INSERT INTO chatsender SET ?'
            db.query(sql, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            const ChatReceiver = {
                ...data,
                video: req.file.filename,
                pushChat: 'pushVideoLeft',
                chatType: 'video',
                hide: 'none',
                hideVideo: 'block',
                hideAudio: 'none',
                hideStory: 'none',
            }

            let sql2 = 'INSERT INTO chatreceiver SET ?'
            db.query(sql2, ChatReceiver, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // **********************************************************************
            // Send notification by adding "+1" to user details
            let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${sencondUser._id}'`
            db.query(sqlForUser, (error) => {
                if (error) return console.log(error)
            })


            // Deleteing old notification so it wont  dublicate
            let sql6 = `DELETE FROM sentchatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
            db.query(sql6, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })


            const chatReeivers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.receiverId}'`)
            let chatReeiver = chatReeivers[0]

            let randomId2 = crypto.randomBytes(12).toString('hex')

            const sentChatNotification = {
                _id: randomId2,
                owner: data.owner,
                ownerName: data.ownerName,
                receiverName: chatReeiver.firstname + ' ' + chatReeiver.lastname,
                message: 'You Sent a video',
                date: data.date,
                avatar: chatReeiver.avatar,
                receiverId: data.receiverId
            }

            let sql3 = 'INSERT INTO sentchatnotification SET ?'
            db.query(sql3, sentChatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Deleteing old notification so it wont  dublicate
            let sql4 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND ownerName='${data.ownerName}'`
            db.query(sql4, (error, result) => { if (error) return console.log(error) })

            // Save the chat notification
            let randomId3 = crypto.randomBytes(12).toString('hex')
            const chatNotification = {
                ...data,
                _id: randomId3,
                lastChat: 'Sent a video',
                avatar: user.avatar,
                ownerName: user.firstname + ' ' + user.lastname
            }

            let sql5 = 'INSERT INTO chatnotification SET ?'
            db.query(sql5, chatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            res.redirect('/chat/' + data.receiverId)
        } catch (error) {
            console.log(error)
            res.redirect('/chat/' + req.params.id)
        }

    }, async (error, req, res, next) => {
        console.log(error)
        res.redirect('/chat/' + req.params.id)
    })




    // send audio immdiately
    io.on('connection', (socket) => {
        socket.on('sendVideo', (data) => {
            socket.broadcast.emit('showVideo', data)
        })
    })


    const storageForChatAudio = multer.diskStorage({
        destination: './web-server/web-folder/public/webStorage/chatAudio',
        filename: function (req, file, cb) {
            cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
        }
    })
    const uploadForChatAudio = multer({
        // limits: 300000,
        storage: storageForChatAudio
    })

    router.post('/chatMusicUpload/:id', auth, uploadForChatAudio.single('uploads'), async (req, res) => {
        try {
            async function SQLQUERRY(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return console.log(error)
                        }
                        resolve(result)
                    })
                })
            }
            // const user = await User.findById(req.user)
            const userx = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.user._id}'`)
            let user = userx[0]

            // const sencondUser = await User.findById(req.params.id)
            const sencondUsers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${req.params.id}'`)
            let sencondUser = sencondUsers[0]

            let data = {
                owner: user._id,
                ownerName: user.firstname + ' ' + user.lastname,
                receiverId: req.params.id,
                receiverName: sencondUser.firstname + ' ' + sencondUser.lastname,
            }


            const Chatsender = {
                ...data,
                _id: new Date(),
                audio: req.file.filename,
                pushChat: 'pushAudioRight',
                chatType: 'audio',
                hide: 'none',
                hideVideo: 'none',
                hideAudio: 'block',
                hideStory: 'none',
            }

            let sql = 'INSERT INTO chatsender SET ?'
            db.query(sql, Chatsender, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            const ChatReceiver = {
                ...data,
                _id: new Date(),
                audio: req.file.filename,
                pushChat: 'pushAudioLeft',
                chatType: 'audio',
                hide: 'none',
                hideVideo: 'none',
                hideAudio: 'block',
                hideStory: 'none',
            }

            let sql2 = 'INSERT INTO chatreceiver SET ?'
            db.query(sql2, ChatReceiver, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Send notification by adding "+1" to user details
            let sqlForUser = `UPDATE users SET chatNotification='+1' WHERE _id='${sencondUser._id}'`
            db.query(sqlForUser, (error) => {
                if (error) return console.log(error)
            })



            // Deleteing old notification so it wont  dublicate
            let sql6 = `DELETE FROM sentchatnotification WHERE owner='${data.owner}' AND receiverId='${data.receiverId}'`
            db.query(sql6, (error, result) => {
                if (error) {
                    return console.log(error)
                }
            })


            // let chatReeiver = await User.findById(data.receiverId)
            const chatReeivers = await SQLQUERRY(`SELECT * FROM users WHERE _id='${data.receiverId}'`)
            let chatReeiver = chatReeivers[0]

            let randomId2 = crypto.randomBytes(12).toString('hex')

            const sentChatNotification = {
                _id: randomId2,
                owner: data.owner,
                ownerName: data.ownerName,
                receiverName: data.receiverName,
                message: 'You Sent an audio',
                date: data.date,
                avatar: chatReeiver.avatar,
                receiverId: data.receiverId

            }

            let sql3 = 'INSERT INTO sentchatnotification SET ?'
            db.query(sql3, sentChatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // Deleteing old notification so it wont  dublicate
            let sql4 = `DELETE FROM chatnotification WHERE owner='${data.owner}' AND ownerName='${data.ownerName}'`
            db.query(sql4, (error, result) => { if (error) return console.log(error) })

            // Save the chat notification            
            let randomId3 = crypto.randomBytes(12).toString('hex')
            const chatNotification = {
                ...data,
                _id: randomId3,
                lastChat: 'Sent an audio',
                avatar: user.avatar,
                ownerName: user.firstname + ' ' + user.lastname
            }

            let sql5 = 'INSERT INTO chatnotification SET ?'
            db.query(sql5, chatNotification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            // If i type over rie the notification message
            res.redirect('/chat/' + data.receiverId)

        } catch (error) {
            console.log(error)
            const sencondUser = await User.findById(req.params.id)
            res.redirect('/chat/' + sencondUser._id)
        }

    }, async (error, req, res, next) => {
        console.log(error)
        const sencondUser = await User.findById(req.params.id)
        res.redirect('/chat/' + sencondUser._id)
    })




    // send audio immdiately
    io.on('connection', (socket) => {
        socket.on('sendAudio', (data) => {
            socket.broadcast.emit('showAudio', data)
        })
    })


    io.on('connection', (socket) => {
        // Read chat notification
        socket.on('readChat', async (data) => {
            let sql = `UPDATE chatnotification SET chatReadColor='cornflowerblue' WHERE _id='${data}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
        })

        // clear chat red notification
        socket.on('removeChatNotification', async (data) => {
            try {
                let sql = `UPDATE users SET chatNotification='' WHERE _id='${data.userId}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })

            } catch (error) {
                console.log(error.message)
            }
        })
    })




    // Delete chat from db
    router.get('/deleteAllChat/:id', auth, async (req, res) => {
        try {
            // await Chatsender.deleteMany({ owner: user._id, receiverId: req.params.id }            
            let sql6 = `DELETE FROM chatsender WHERE owner='${req.user._id}' AND receiverId='${req.params.id}'`
            db.query(sql6, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            // await ChatReceiver.deleteMany({ receiverId: user._id, owner: req.params.id })

            let sql = `DELETE FROM chatreceiver WHERE receiverId='${req.user._id}' AND owner='${req.params.id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            res.redirect('/home')
        } catch (error) {
            console.log(error)
            // res.redirect('/home')
        }

    })

    // Delete single chat
    router.post('/deleteMessage/:id', auth, async (req, res) => {
        let sql = `DELETE FROM chatsender WHERE _id='${req.body.data}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let sql2 = `DELETE FROM chatreceiver WHERE _id='${req.body.data}'`
        db.query(sql2, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        res.redirect('/chat/' + req.params.id)
    })


    // Delete single chat image 
    router.post('/deleteImg/:id', auth, async (req, res) => {

        let sql = `DELETE FROM chatsender WHERE id='${req.body.data}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let sqlx = `DELETE FROM chatreceiver WHERE id='${req.body.data}'`
        db.query(sqlx, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        async function SQLQUERRY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)

                })
            })
        }

        const findChat = await SQLQUERRY(`SELECT * FROM chatsender WHERE _id='${req.body.data}'`)
        let chat = findChat[0]
        console.log(chat)

        if (findChat.length != 0) {
            fs.unlink('./web-server/web-folder/public/webStorage/chatImages/' + chat.image, (error) => {
                if (!error) {
                    console.log('Deleted successfully')
                }
            })

        }
        res.redirect('/chat/' + req.params.id)
    })


    // delete chat message from chat notification or chat message
    router.get('/deletemessage/:id/:owner', auth, async (req, res) => {
        let sql = `DELETE FROM chatnotification WHERE _id='${req.params.id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let sql2 = `DELETE FROM chatsender WHERE WHERE owner='${req.user._id}' AND receiverId='${req.params.owner}'`
        db.query(sql2, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let sql4 = `DELETE FROM chatreceiver WHERE WHERE receiverId='${req.user._id}' AND owner='${req.params.owner}'`
        db.query(sql4, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let sql5 = `DELETE FROM chatsender WHERE WHERE _id='${req.params.id}'`
        db.query(sql5, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        res.redirect('/home')

    })


    // Delete single chat image 
    router.get('/deletevideo/:id/:receiverId', auth, async (req, res) => {

        async function SQLQUERRY(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const findChat = await SQLQUERRY(`SELECT * FROM chatsender WHERE _id='${req.params.id}'`)
        let chat = findChat[0]

        if (findChat.length != 0) {
            fs.unlink('./web-server/web-folder/public/webStorage/chatVideos/' + chat.video, (error) => {
                if (!error) {
                    console.log('Deleted successfully')
                }
            })

            let sql5 = `DELETE FROM chatsender WHERE _id='${req.params.id}'`
            db.query(sql5, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let sql6 = `DELETE FROM chatreceiver WHERE _id='${req.params.id}'`
            db.query(sql6, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


        }
        res.redirect('/chat/' + req.params.receiverId)
    })


    // delete chat my sent message from chat notification or chat message


    return router
}


