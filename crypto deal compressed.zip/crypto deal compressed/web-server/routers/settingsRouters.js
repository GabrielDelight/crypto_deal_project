const router = require('express').Router()
const User = require('../models/model');
const path = require('path');
const auth = require('./auth');
const multer = require('multer');
const mysql = require('mysql');
const crypto = require('crypto')

const Post = require('../models/postModel')
const Comment = require('../models/comments')
const ShearedPost = require('../models/sharedPostModel')
const FakeAvatar = require('../models/fakeavatar')
const FakeFemaleAvatar = require('../models/fakeFemaleAvatar')
const Reply = require('../models/replyComment')
const FakeCoverPhoto = require('../models/fakeCoverPhoto')
const StaticErrorImage = require('../models/notFoundImage')


const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})



db.connect((error) => {
    if (error) {
        console.log(error)
    }
    
})

let monthsArray;
let month;
let newMonth;
let day = new Date().getDay();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = ` ${day} ${newMonth},  ${year}`


// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/coverPhoto',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})

router.get('/readme', auth, async (req, res) => {
    const user = await User.findById(req.user)
    res.render('settings/readme', {
        user: user
    })
})




// Upload image route

router.get('/myphoto', auth, async (req, res) => {
    const user = await User.findById(req.user)
    res.render('settings/myphoto', {
        user: user
    })
})


const avatarStorage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/avatar',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const avatarUpload = multer({
    // limits: 300000,
    storage: avatarStorage
})

router.post('/myphoto', auth, avatarUpload.single('uploads'), async (req, res) => {

    async function SQL(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    const user = userSQL[0]

    let sql = `UPDATE users SET avatar='${req.file.filename}' WHERE _id='${user._id}'`
    db.query(sql, (error) => {
        if (error) {
            return console.log(error)
        }
    })


    let sqlForPost = `UPDATE posts SET avatar='${req.file.filename}' WHERE owner='${user._id}'`
    db.query(sqlForPost, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    let alluserPostShared = `UPDATE sharePost SET avatar='${req.file.filename}' WHERE owner='${user._id}'`
    db.query(alluserPostShared, (error) => {
        if (error) {
            return console.log(error)
        }
    })


    let allUserComments = `UPDATE comments SET avatar='${req.file.filename}' WHERE owner='${user._id}'`
    db.query(allUserComments, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    let alluserReplies = `UPDATE replies SET avatar='${req.file.filename}' WHERE owner='${user._id}'`
    db.query(alluserReplies, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    res.redirect('/profile/' + user._id)

}, async (error, req, res, next) => {
    const user = await User.findById(req.user)

    res.render('settings/myphoto', {
        user,
        error: error.message
    })
})



router.post('/coverPhoto', upload.single('uploads'), auth, async (req, res) => {
    try {
        let sql = `UPDATE users SET coverPhoto='${req.file.filename}' WHERE _id='${req.user._id}'`
        db.query(sql, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        res.redirect('/profile/' + req.user._id)

    } catch (error) {
        const user = await User.findById(req.user._id);
        res.redirect('/profile/' + user._id)
    }
}, (error, req, res, next) => {
    res.redirect('/profile/' + req.user._id)
})



//=========================================================
router.get('/mobileNav', auth, async (req, res) => {
    async function SQL(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return res.redirect('/login')
                }
                resolve(result)
            })
        })
    }

    const userSQL = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    const user = userSQL[0]
    
    res.render('mobileNavs', {
        user,
    })
})

module.exports = router