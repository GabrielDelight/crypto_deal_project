const router = require('express').Router();
const Post = require('../models/postModel');
const SharedPost = require('../models/sharedPostModel')
const auth = require('./auth')
const ChatNotification = require('../models/chatNotification')
const Comment = require('../models/comments');
const User = require('../models/model')
const Reply = require('../models/replyComment')
const Notification = require('../models/notification')
const multer = require('multer');
const path = require('path')
const mysql = require('mysql');
const crypto = require('crypto')

// Set created date
let monthsArray;
let month;
let newMonth;
let day = new Date().getDay();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = ` ${day} ${newMonth},  ${year}`

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }
})



router.get('/shareLink/:id', auth, async (req, res) => {
    try {
        async function GETSQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const users = await GETSQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const posts = await GETSQL(`SELECT * FROM sharepost WHERE _id='${req.params.id}'`)
        const comments = await GETSQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)

        const user = users[0]
        const post = posts[0]


        res.render('viewSharedPostImage', {
            user: user,
            postDetails: post,
            comment: comments
        })

    } catch (error) {
        console.log(error.message)
        res.render('404Page')
    }

})


// video router
router.get('/sharedLinkVideo/:id', auth, async (req, res) => {
    try {
        async function GETSQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const users = await GETSQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const posts = await GETSQL(`SELECT * FROM sharepost WHERE _id='${req.params.id}'`)
        const comments = await GETSQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)

        const user = users[0]
        const post = posts[0]

        res.render('viewSharedPostVideo', {
            user: user,
            postDetails: post,
            comment: comments
        })

    } catch (error) {
        console.log(error.message)
        res.render('404Page')
    }

})



// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/commentImages',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})



// COmment
router.post('/shareComment', auth, upload.single('uploadImg'), async (req, res) => {

    async function SQL(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }

    const userx = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let user = userx[0]


    let verify = user.verified

    try {

        let id = req.body.redirectId
        const posts = await SQL(`SELECT * FROM sharepost WHERE _id='${id}'`)
        let post = posts[0]


        let image;
        let hideImage = 'none'
        if (req.file) {
            image = req.file.filename
            hideImage = 'block'
        }

        const _id = crypto.randomBytes(12).toString('hex')

        const comment = {
            comment: req.body.comment,
            _id,
            owner: user._id,
            postId: id,
            fullName: `${user.firstname} ${user.lastname}`,
            image,
            hideImage,
            date: fullDateStr,
            commentorNickName: user.fullName,
            verified: verify,
            avatar: user.avatar,
            hideReply: 'none',
        }

        let sql = 'INSERT INTO comments SET ?'
        db.query(sql, comment, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let updatesql = `UPDATE sharepost SET commentlength='${req.body.commentLength}' WHERE _id='${post._id}'`
        db.query(updatesql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let updateLastCommentInPost = `UPDATE sharepost SET commentlength='${req.body.commentLength}',Initcomment='${req.body.comment}',commentImage='${user._id}',commentName='${user.firstname} ${user.lastname}',verifiedComment='${user.verified}',commentWidth='20',commentHeight='20',hideLastComment='block',lastCommentAvatar='${user.avatar}' WHERE _id='${posts[0]._id}'`

        db.query(updateLastCommentInPost, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let redirectId = 'sharedLinkVideo/'

        if (post.postType == 'image' || post.postType == 'text') {
            redirectId = `shareLink/`
        }

        res.redirect('/' + redirectId + post._id)

        const checkowner = post.owner.toString() !== user._id.toString()
        if (checkowner) {
            const notification = {
                owner: user._id,
                _id: crypto.randomBytes(12).toString('hex'),
                text: 'Commented on your post',
                comment: req.body.comment,
                eventId: id,
                eventOwner: post.owner,
                date: fullDateStr,
                ownerName: `${user.firstname} ${user.lastname}`,
                avatar: user.avatar,
                urlLink: redirectId + id
            }

            let sql = 'INSERT INTO notification SET ?'
            db.query(sql, notification, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            


            let findNotifcationOwner = await SQL(`SELECT * FROM users WHERE _id='${post.owner}'`)
            let eventOwner = findNotifcationOwner[0]
            if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${post.owner}'`
                db.query(sql, (error) => {
                    if (error) return console.log(error)
                })
                res.redirect('/' + redirectId + post._id)
                return
            } else {
                let count = parseInt(eventOwner.notifiicationLength)
                count = count += 1
                let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${post.owner}'`
                db.query(sqlQueryForCOunt, (error) => {
                    if (error) return console.log(error)
                })
            }
            

        }






    } catch (error) {
        console.log(error)
        res.redirect(`/shareLink/${id}`)
    }

}, (error, req, res, next) => {
    res.redirect('/home')
})





// Delete comment
router.get('/deleteSharedImage/:id', async (req, res) => {
    const comment = await Comment.findByIdAndDelete(req.params.id);
    await Reply.deleteMany({ mainCommentId: comment._id })
    res.redirect(`/shareLink/${comment.postId}`)

    // decrease the comment number by decrementng the vale
    const post = await SharedPost.findByIdAndUpdate({ _id: comment.postId })
    let len = parseInt(post.commentlength)
    let newLen = len -= 1 //decrementing
    post.commentlength = newLen
    await post.save()

})


module.exports = router