const router = require('express').Router()
const User = require('../models/model')
module.exports = function(io){
    router.get('/connection', (req,res) => {
        
    })


    io.on('connection', (socket) => {        
        
        socket.on('sendUserDetails', async (data) => {            
            const user = await User.findById(data)
            user.activeStatus = 'online'
            user.greenActive  = 'green'
            await user.save()
            
            

            socket.on('disconnect', async () => {                
                user.activeStatus = 'offline'
                user.greenActive = 'none'
                await user.save()
            })
        })

    })

    
    return router
}