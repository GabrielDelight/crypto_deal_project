const router = require('express').Router();
const auth = require('./auth')
const multer = require('multer');
const path = require('path')
const mysql = require('mysql');
const crypto = require('crypto')


// Set created date
let monthsArray;
let month;
let newMonth;
let day = new Date().getDay();
let year = new Date().getFullYear();
let time = new Date().toLocaleTimeString();
monthsArray = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
month = new Date().getMonth();
newMonth = monthsArray[month];
let fullDateStr = ` ${day} ${newMonth},  ${year}`

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})



db.connect((error) => {
    if (error) {
        console.log(error)
    }
})


router.get('/viewImagePostDetails/:id', auth, async (req, res) => {
    try {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users WHERE _id='${val}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userx = await User(req.user._id)
        let user = userx[0]

        async function SQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const post = await SQL(`SELECT * FROM posts WHERE _id='${req.params.id}'`)
        const comments = await SQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)

        res.render('viewFullImage', {
            user: user,
            postDetails: post[0],
            comment: comments,
            // chatNotification,
        })

    } catch (error) {
        console.log(error.message)
        res.render('404Page')
    }

})



// video
router.get('/viewVideoPostDetails/:id', auth, async (req, res) => {
    try {

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = `SELECT * FROM users WHERE _id='${val}'`
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }
        const userx = await User(req.user._id)
        let user = userx[0]

        async function SQL(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return console.log(error)
                    }
                    resolve(result)
                })
            })
        }

        const post = await SQL(`SELECT * FROM posts WHERE _id='${req.params.id}'`)
        const comments = await SQL(`SELECT * FROM comments WHERE postId='${req.params.id}'`)

        res.render('viewFullVideo', {
            user: user,
            postDetails: post[0],
            comment: comments,
        })

    } catch (error) {
        console.log(error.message)
        res.render('404Page')
    }

})



// @ set up validation for image upload
const storage = multer.diskStorage({
    destination: './web-server/web-folder/public/webStorage/commentImages',
    filename: function (req, file, cb) {
        cb(null, 'plogapp' + '-' + Date.now() + path.extname(file.originalname))
    }
})
const upload = multer({
    // limits: 300000,
    storage: storage
})


// COmment
router.post('/getComment', auth, upload.single('uploadImg'), async (req, res) => {
    async function SQL(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }

    const userx = await SQL(`SELECT * FROM users WHERE _id='${req.user._id}'`)
    let user = userx[0]


    
    try {
        let verify = user.verified

        let id = req.body.redirectId
        const posts = await SQL(`SELECT * FROM posts WHERE _id='${id}'`)
        let post = posts[0]


        let image;
        let hideImage = 'none'
        if (req.file) {
            image = req.file.filename
            hideImage = 'block'
        }

        const _id = crypto.randomBytes(12).toString('hex')

        const comment = {
            comment: req.body.comment,
            _id,
            owner: user._id,
            postId: id,
            fullName: `${user.firstname} ${user.lastname}`,
            image,
            hideImage,
            date: fullDateStr,
            commentorNickName: user.fullName,
            verified: verify,
            avatar: user.avatar,
            hideReply: 'none',
        }

        let sql = 'INSERT INTO comments SET ?'
        db.query(sql, comment, (error) => {
            if (error) {
                return console.log(error)
            }
        })

        let updatesql = `UPDATE posts SET commentlength='${req.body.commentLength}' WHERE _id='${post._id}'`
        db.query(updatesql, (error) => {
            if (error) {
                return console.log(error)
            }
        })


        let updateLastCommentInPost = `UPDATE posts SET commentlength='${req.body.commentLength}',Initcomment='${req.body.comment}',commentImage='${user._id}',commentName='${user.firstname} ${user.lastname}',verifiedComment='${user.verified}',commentWidth='20',commentHeight='20',hideLastComment='block',lastCommentAvatar='${user.avatar}' WHERE _id='${posts[0]._id}'`

        db.query(updateLastCommentInPost, (error) => {
            if (error) {
                return console.log(error)
            }
        })



        let redirectId = 'viewVideoPostDetails/'

        if (post.postType == 'image' || post.postType == 'text') {
            redirectId = `viewImagePostDetails/`
        }

        res.redirect('/' + redirectId + post._id)
       
        const checkowner = post.owner.toString() !== user._id.toString()
        if (checkowner) {
            const notification = {
                owner: user._id,
                _id: crypto.randomBytes(12).toString('hex'),
                text: 'Commented on your post',
                comment: req.body.comment,
                eventId: id,
                eventOwner: post.owner,
                date: fullDateStr,
                ownerName: `${user.firstname} ${user.lastname}`,
                avatar: user.avatar,
                urlLink: redirectId + id
            }

            let sql = 'INSERT INTO notification SET ?'
            db.query(sql, notification, (error) => {
                if (error) {
                    return console.log(error)
                }
                console.log('Created a new Nitification')
            })


            let findNotifcationOwner = await SQL(`SELECT * FROM users WHERE _id='${post.owner}'`)
            let eventOwner = findNotifcationOwner[0]
            if (eventOwner.notifiicationLength == '' || eventOwner.notifiicationLength == null) {
                let sql = `UPDATE users SET notifiicationLength='${1}' WHERE _id='${post.owner}'`
                db.query(sql, (error) => {
                    if (error) return console.log(error)
                })                
                return
            } else {
                let count = parseInt(eventOwner.notifiicationLength)
                count = count += 1
                let sqlQueryForCOunt = `UPDATE users SET notifiicationLength='${count}' WHERE _id='${post.owner}'`
                db.query(sqlQueryForCOunt, (error) => {
                    if (error) return console.log(error)
                })
            }
        }

        


    } catch (error) {
        console.log(error)
    }

}, (error, req, res, next) => {
    res.redirect('/home')
})



// Delete comment
router.get('/deleteComment/:id', async (req, res) => {


    async function SQL(val) {
        return new Promise((resolve, reject) => {
            let sql = val
            db.query(sql, (error, result) => {
                if (error) {
                    return console.log(error)
                }
                resolve(result)
            })
        })
    }

    const comment = await SQL(`SELECT * FROM comments WHERE _id='${req.params.id}'`)
    const posts = await SQL(`SELECT * FROM posts WHERE _id='${comment[0].postId}'`)
    let post = posts[0]

    let sql = `DELETE  FROM comments WHERE _id='${req.params.id}'`
    db.query(sql, (error, result) => {
        if (error) {
            return console.log(error)
        }
        console.log('Comments Deleted successful')
    })



    const allcomments = await SQL(`SELECT * FROM comments WHERE postId='${post._id}'`)
    console.log(allcomments.length)

    let updatesql = `UPDATE posts SET commentLength='${allcomments.length}' WHERE id='${post.id}'`
    db.query(updatesql, (error) => {
        if (error) {
            return console.log(error)
        }
    })

    let redirectId = '/viewVideoPostDetails/'

    if (post.postType == 'image' || post.postType == 'text') {
        redirectId = `/viewImagePostDetails/`
    }

    res.redirect(redirectId + post._id)

})


module.exports = router