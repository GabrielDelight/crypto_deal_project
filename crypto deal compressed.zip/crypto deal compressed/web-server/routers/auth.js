const jwt = require('jsonwebtoken');

module.exports = function auth(req, res, next){
    const token = req.cookies.auth_token
    if(!token){
        return res.redirect('/')          
    }
    
    try{
        const verifyToken = jwt.verify(token, process.env.JWT_SECRET);
        req.user = verifyToken;        
        next()
    }catch(error){
        console.log(error)
        res.redirect('/login')          
    }
}