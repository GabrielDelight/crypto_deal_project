const router = require('express').Router()
const mysql = require('mysql');
const crypto = require('crypto')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }
})

module.exports = function (io) {

    io.on('connection', (socket) => {
        socket.on('hideWelcomeMsg', async (data) => {
            let sql = `UPDATE users SET hideWelcomeMsg='${data.display}' WHERE _id='${data.id}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
        })
    })


    return router
}