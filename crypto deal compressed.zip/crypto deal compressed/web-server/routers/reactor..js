const router = require('express').Router()
const User = require('../models/model')
const auth = require('./auth')
const Post = require('../models/postModel')
const SharedPost = require('../models/sharedPostModel')
const mysql = require('mysql');
const crypto = require('crypto')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }
    
})


module.exports = function (io) {

    io.on('connection', (socket) => {
        socket.on('sendPostIdForReaction', async id => {
            try {
                async function SQLQUERRY(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }

                const findPost = await SQLQUERRY(`SELECT * FROM posts WHERE _id='${id}'`)
                let post = findPost[0]

                // const post = await Post.findById(id)
                let reactionIds = post.reaction.split(',');

                // loop to get the iser
                let newReactorsId = []
                for (i = 0; i < reactionIds.length; i++) {
                    const user = await SQLQUERRY(`SELECT * FROM users WHERE id='${reactionIds[i]}'`)
                    
                    user.forEach(cur => {
                        newReactorsId.push(cur)

                    })
                    
                }


                let fetchedUsers = []
                newReactorsId.forEach(val => {
                    val.coverPhoto = undefined
                    val.storyImg = undefined
                    val.password = undefined
                    val.hasStory = undefined
                    val.gender = undefined
                    val.phoneNumber = undefined
                    val.email = undefined
                    val.bestSentence = undefined
                    val.date = undefined
                    val.genderDescription = undefined
                    val.month = undefined
                    val.month = undefined
                    val.year = undefined
                    val.activeStatus = undefined
                    val.greenActive = undefined
                    val.notifiicationLength = undefined
                    val.createdAt = undefined
                    val.token = undefined
                    val.updatedAt = undefined
                    val.hideWelcomeMsg = undefined
                    val.chatNotification = undefined
                    val.fullName = undefined
                    fetchedUsers.push(val)
                })

                socket.emit('reaction-users', fetchedUsers)

            } catch (error) {
                
                async function SQLQUERRY(val) {
                    return new Promise((resolve, reject) => {
                        let sql = val
                        db.query(sql, (error, result) => {
                            if (error) {
                                return console.log(error)
                            }
                            resolve(result)
                        })
                    })
                }

                const findPost = await SQLQUERRY(`SELECT * FROM sharepost WHERE _id='${id}'`)
                let post = findPost[0]

                // const post = await Post.findById(id)
                let reactionIds = post.reaction.split(',');

                // loop to get the iser
                let newReactorsId = []
                for (i = 0; i < reactionIds.length; i++) {
                    const user = await SQLQUERRY(`SELECT * FROM users WHERE id='${reactionIds[i]}'`)
                    
                    user.forEach(cur => {
                        newReactorsId.push(cur)

                    })
                    
                }
                let fetchedUsers = []
                newReactorsId.forEach(val => {
                    val.coverPhoto = undefined
                    val.storyImg = undefined
                    val.password = undefined
                    val.hasStory = undefined
                    val.gender = undefined
                    val.phoneNumber = undefined
                    val.email = undefined
                    val.bestSentence = undefined
                    val.date = undefined
                    val.genderDescription = undefined
                    val.month = undefined
                    val.month = undefined
                    val.year = undefined
                    val.activeStatus = undefined
                    val.greenActive = undefined
                    val.notifiicationLength = undefined
                    val.createdAt = undefined
                    val.token = undefined
                    val.updatedAt = undefined
                    val.hideWelcomeMsg = undefined
                    val.chatNotification = undefined
                    val.fullName = undefined
                    fetchedUsers.push(val)
                })

                socket.emit('reaction-users', fetchedUsers)

            }

        })
    })



    router.get('/reactors/:id', auth, async (req, res) => {
        try {
            const user = await User.findById(req.user)
            const post = await Post.findById(req.params.id)
            let reactionIds = post.reaction;

            let newId = []
            reactionIds.forEach(cur => {
                cur.forEach(val => {
                    newId.push(val)
                })
            })

            // loop to get the iser
            let newReactorsId = []
            for (i = 0; i < newId.length; i++) {
                const reactorsId = await User.findById(newId[i])
                newReactorsId.push(reactorsId)
            }



            res.render('reactors', {
                user,
                userReactor: newReactorsId,
                message: 'Replies'
            })

        }
        catch (error) {
            res.render('reactors', {
                message: 'No reactor '
            })

        }
    })

    return router
}

