const router = require('express').Router()
const auth = require('./auth');
const mysql = require('mysql');
const crypto = require('crypto')

const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }
    
})


module.exports = function (io) {
    let publickParams = []
    router.get('/follower/:id', auth, async (req, res) => {

        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        let users = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        let user = users[0]
        let followerUser = await User(`SELECT * FROM users WHERE _id='${req.params.id}'`)
        followerUser = followerUser[0]
        let followers = followerUser.follower.split(',')


        // @ get user followers
        let newFollowersArr = []
        for (i = 0; i < followers.length; i++) {
            const findusers = await User(`SELECT * FROM users WHERE id='${followers[i]}'`)
            findusers.forEach(val => {
                newFollowersArr.push(val)
            })
        }


        //@ Create suggestion fot user to follow____________________
        const allUsers = await User(`SELECT * FROM users`)
        let myFolloingArr = user.following + user.id
        let notFollowingIdsArray = []
        for (i = 0; i < allUsers.length; i++) {
            if (!myFolloingArr.includes(allUsers[i].id)) {
                notFollowingIdsArray.push(allUsers[i].id)
            }
        }

        let newUserTOFollow = []
        for (i = 0; i < notFollowingIdsArray.length; i++) {
            const fetchUsersToFollow = await User(`SELECT * FROM users WHERE id='${notFollowingIdsArray[i]}'`)
            fetchUsersToFollow.forEach(val => {
                newUserTOFollow.push(val)
            })
        }

        newUserTOFollow = newUserTOFollow.sort(() => Math.random() - 0.5)
        newUserTOFollow = newUserTOFollow.splice(0, 4)
        // @_______________________________________________________

        // @ get four (4) post 
        let allPostsSuggestedPost = await User(`SELECT * FROM posts WHERE postType='image'`)
        allPostsSuggestedPost = allPostsSuggestedPost.sort(() => Math.random() - 0.5)
        allPostsSuggestedPost = allPostsSuggestedPost.splice(0, 2)

        // get reaction
        let notification = await User(`SELECT * FROM notification WHERE eventOwner='${user._id}' ORDER BY id DESC`)

        res.render('follower', {
            user,
            // chatNotification,
            // userFollowers,
            followers: newFollowersArr,
            paramsId: req.params.id,
            suggestedArr: newUserTOFollow,
            posts: allPostsSuggestedPost,
            notification,
            // users,
            // sentChatNotification,
            // paramsname: userFollowers.firstname,

        })
    })


    io.on('connection', socket => {
        socket.on('sendUserIdToGetFollowers', async (xId) => {
            const userFollowers = await User.findById(xId.paramsId)
            let followerArr = userFollowers.follower;

            let idsArr = []
            followerArr.forEach(cur => {
                cur.forEach(val => {
                    idsArr.push(val)
                })
            })


            let getFollowers = ''
            let newUserArr = []
            for (i = 0; i < idsArr.length; i++) {
                getFollowers = await User.findById(idsArr[i]);
                newUserArr.push(getFollowers)
            }

            let filteredArr = []
            newUserArr.forEach(cur => {
                cur.coverPhoto = undefined
                cur.storyImg = undefined
                cur.password = undefined
                cur.hasStory = undefined
                cur.gender = undefined
                cur.phoneNumber = undefined
                cur.email = undefined
                cur.verified = undefined
                cur.date = undefined
                cur.genderDescription = undefined
                cur.month = undefined
                cur.month = undefined
                cur.year = undefined
                cur.activeStatus = undefined
                cur.greenActive = undefined
                cur.notifiicationLength = undefined
                cur.createdAt = undefined
                cur.token = undefined
                cur.updatedAt = undefined
                cur.hideWelcomeMsg = undefined
                cur.fullName = undefined
                filteredArr.push(cur)
            })

            let shuffledFollowers = filteredArr.sort(() => Math.random() - 0.5)

            socket.emit('follower-socket', shuffledFollowers)
        })
    })


    router.get('/follower-api', auth, async (req, res) => {
        try {
            let newParamsId = publickParams[publickParams.length - 1]
            let xId = newParamsId.toString()

            const user = await User.findById(req.user)
            const userFollowers = await User.findById(xId)

            let followerArr = userFollowers.follower;
            let idsArr = []
            followerArr.forEach(cur => {
                cur.forEach(val => {
                    idsArr.push(val)
                })
            })

            let getFollowers = ''
            let newUserArr = []
            for (i = 0; i < idsArr.length; i++) {
                getFollowers = await User.findById(idsArr[i]);
                newUserArr.push(getFollowers)
            }

            let filteredArr = []
            newUserArr.forEach(cur => {
                filteredArr.push(cur)
            })

            let shuffledFollowers = filteredArr.sort(() => Math.random() - 0.5)
            res.send(shuffledFollowers)
            publickParams = []

        } catch (error) {
            console.log('Error occured')
        }

    })

    return router
}