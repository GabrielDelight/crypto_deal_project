const router = require('express').Router();
const User = require('../models/model');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken')
const auth = require('./auth')
const multer = require('multer');
const mysql = require('mysql');
const crypto = require('crypto')

const Post = require('../models/postModel')
const Comment = require('../models/comments')
const Reply = require('../models/replyComment')
const nodemailer = require('nodemailer')
const SharedPost = require('../models/sharedPostModel')



const db = mysql.createConnection({
    host: 'localhost',
    user: process.env.database_user,
    database: process.env.database_name,
    password: process.env.database_password
})


db.connect((error) => {
    if (error) {
        console.log(error)
    }
})



module.exports = function (io) {

    // Update user details ****************************
    router.get('/update', auth, async (req, res) => {
        async function User(val) {
            return new Promise((resolve, reject) => {
                let sql = val
                db.query(sql, (error, result) => {
                    if (error) {
                        return res.redirect('/login')
                    }
                    resolve(result)
                })
            })
        }

        const userSQL = await User(`SELECT * FROM users WHERE _id='${req.user._id}'`)
        const user = userSQL[0]

        res.render('settings/update', {
            user: user,
        })
    })



    // socket function
    io.on('connection', async socket => {
        socket.on('deleteInfo', async (data) => {
            const user = await User.findById(data.deleteOwner)
            const hash = await bcrypt.compare(data.deletePassword, user.password)
            if (!hash) {
                socket.emit('wrongPassword', 'Wrong password')
                return
            }
            socket.emit('showCnfirmBtn', 'block')
        })

        //@ confirm delete account --------
        socket.on('coinfirmPassword', async data => {
            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }
    
            const userSQL = await User(`SELECT * FROM users WHERE _id='${data.userid}'`)
            const user = userSQL[0]
            // const user = await User.findById(data.userid)
            const hash = await bcrypt.compare(data.currentPassword, user.password)
            if (!hash) {
                socket.emit('wrongChangePass', 'Wrong password')
                return
            }

            // hash password
            const newPass = await bcrypt.hash(data.newPassword, 10)


            let sql = `UPDATE users SET password='${newPass}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            socket.emit('passwordSuccess')
        })


        // chnaging ur email address
        socket.on('emailInfo', async data => {
            const user = await User.findById(data.userid) //user
            // @ send 6 random digits to the givin email
            let code1 = Math.floor(Math.random() * 10)
            let code2 = Math.floor(Math.random() * 10)
            let code3 = Math.floor(Math.random() * 10)
            let code4 = Math.floor(Math.random() * 10)
            let code5 = Math.floor(Math.random() * 10)
            let code6 = Math.floor(Math.random() * 10)

            let code = [code1, code2, code3, code4, code5, code6]
            code = code.map(el => el.toString())
            code = code.toString().replace(/,/g, '')
            console.log(code)
            // Send mail
            // ********************************* send mail
            var smtpConfig = {
                host: 'smtp.gmail.com',
                port: 587,
                secure: false,
                requireTLS: true,
                auth: {
                    user: 'gabrieldelight08@gmail.com',
                    pass: '08082052459'
                }
            };
            var transporter = nodemailer.createTransport(smtpConfig);

            let codeText = 'Code: ' + code
            const mailOptions = {
                from: 'gabrieldelight08@gmail.com',
                to: user.email,
                subject: code + ' is your Plorged App email rest  code',
                html: `We received a request to reset your Plorged App email address.
        Enter the following password reset code: ${codeText} `
            }

            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    return console.log(error)
                } else {
                    console.log('Sent to: ' + info.response)
                }
            })



            user.verificationCode = code
            await user.save()

            socket.emit('oldverifyEmail')
        })

        // verifying the email sent to the mail
        socket.on('emailVerificationCode', async data => {
            const user = await User.findById(data.userid) //user
            if (user.verificationCode !== data.code) {
                socket.emit('rejectCode', 'Invalid code, please check your email and confirm again')
                return
            }
            user.email = data.email
            user.verificationCode = ''
            await user.save()
            socket.emit('changeEmailSuccess')
        })

        // @ number section for modifying
        socket.on('numberInfo', async data => {
            const user = await User.findById(data.userid) //user
            // @ send 6 random digits to the givin email
            let code1 = Math.floor(Math.random() * 10)
            let code2 = Math.floor(Math.random() * 10)
            let code3 = Math.floor(Math.random() * 10)
            let code4 = Math.floor(Math.random() * 10)
            let code5 = Math.floor(Math.random() * 10)
            let code6 = Math.floor(Math.random() * 10)
            let code = [code1, code2, code3, code4, code5, code6]
            code = code.map(el => el.toString())
            code = code.toString().replace(/,/g, '')
            console.log(code)

            // use node mailer to send code here ****************



            user.verificationCode = code
            await user.save()

            socket.emit('verifyNumber')

        })


        socket.on('confirmMobileCode', async data => {
            const user = await User.findById(data.userid) //user
            if (user.verificationCode !== data.code) {
                socket.emit('rejectPhoneCode', 'Invalid code, please check your phone and confirm again')
                return
            }
            user.phoneNumber = data.newNumber.toString()
            user.verificationCode = ''
            await user.save()
            socket.emit('changePhoneSuccess')

        })


        socket.on('nicknameInfo', async data => {

            async function User(val) {
                return new Promise((resolve, reject) => {
                    let sql = val
                    db.query(sql, (error, result) => {
                        if (error) {
                            return res.redirect('/login')
                        }
                        resolve(result)
                    })
                })
            }

            const userSQL = await User(`SELECT * FROM users WHERE fullName='${data.newNickname}'`)

            if (userSQL.length == 0) {
                let sql = `UPDATE users SET fullName='${data.newNickname}' WHERE _id='${data.userid}'`
                db.query(sql, (error) => {
                    if (error) {
                        return console.log(error)
                    }
                })
                socket.emit('nicknameSuccess', 'Nickname changed succesfuly.')
                return
            }

            socket.emit('nicknameExist', data.newNickname + ' has already been taken.')
        })


        socket.on('fullNameInfo', async data => {
            let sql = `UPDATE users SET firstname='${data.firstname}', lastname='${data.lastname}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let sql2 = `UPDATE posts SET possterName='${data.firstname + ' ' + data.lastname}' WHERE owner='${data.userid}'`
            db.query(sql2, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            let sql3 = `UPDATE sharepost SET possterName='${data.firstname + ' ' + data.lastname}' WHERE owner='${data.userid}'`
            db.query(sql3, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            let sql4 = `UPDATE comments SET fullName='${data.firstname + ' ' + data.lastname}' WHERE owner='${data.userid}'`
            db.query(sql4, (error) => {
                if (error) {
                    return console.log(error)
                }
            })


            let sql5 = `UPDATE replies SET fullName='${data.firstname + ' ' + data.lastname}' WHERE owner='${data.userid}'`
            db.query(sql5, (error) => {
                if (error) {
                    return console.log(error)
                }
            })

            socket.emit('fullNameSuccess', 'You\'ve successfully chnaged your fullname.')
        })


        // @ gender +++++++++++++++++++--------------
        socket.on('genderInfo', async data => {
            let sql = `UPDATE users SET gender='${data.gender}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
                socket.emit('successInGender', 'You\'ve successfully chnaged your gender to ' + data.gender + '.')
            })
        })


        // bip
        socket.on('bioInfo', async data => {
            let sql = `UPDATE users SET bestSentence='${data.bio}' WHERE _id='${data.userid}'`
            db.query(sql, (error) => {
                if (error) {
                    return console.log(error)
                }
            })
            socket.emit('bioSuccess', 'You\'ve successfully chnaged your bio')
        })

    })






    // router.post('/deleteMyAccount', auth, async (req, res) => {
    //     // disble this accout nstead
    //     const user = await User.findById(req.user);
    //     user.isDisabled = true
    //     await user.save()
    //     res.clearCookie('auth_token').redirect('/login') //Clear cookie
    // })

    // @ run check for diabled share post acccount
    async function myFUnction() {
        try {
            const post = await Post.find()
            for (i = 0; i < post.length; i++) {
                let user = await User.findById(post[i].owner)
                post[i].isDisabled = user.isDisabled
                await post[i].save()
            }
        } catch (error) {
        }
    }
    setInterval(myFUnction, 1500)


    // @ run check for diabled share Comment acccount
    async function myFUnction2(req, res, next) {
        try {
            const comment = await Comment.find()
            for (i = 0; i < comment.length; i++) {
                let user = await User.findById(comment[i].owner)
                comment[i].isDisabled = user.isDisabled
                await comment[i].save()
            }
        } catch (error) {
        }
    }
    setInterval(myFUnction2, 1500)


    // @ run check for diabled share post acccount
    async function myFUnction3(req, res, next) {
        try {
            const sharedPost = await SharedPost.find()
            for (i = 0; i < sharedPost.length; i++) {
                let user = await User.findById(sharedPost[i].owner)
                sharedPost[i].isDisabled = user.isDisabled
                await sharedPost[i].save()
            }
        } catch (error) {
        }
    }
    setInterval(myFUnction3, 1500)


    return router
}