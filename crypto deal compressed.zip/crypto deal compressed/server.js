const express = require('express');
require('events').EventEmitter.prototype._maxListeners = 100;
const path = require('path');
const hbs = require('hbs');
const http = require('http');
const app = express();
const server = http.createServer(app);
const socketio = require('socket.io');
const io = socketio(server)
const session = require('express-session')
const crypto = require('crypto')
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser');;

// Get routers **************************************************
const userRouter = require('./web-server/routers/rout');

const port = process.env.PORT;

// Configure and serving files
const publicDirPath = path.join(__dirname, '/web-server/web-folder/public');
const viewPath = path.join(__dirname, '/web-server/web-folder/views');
const partialDirctory = path.join(__dirname, '/web-server/web-folder/partials');

app.set('view engine', 'hbs')
app.set('views', viewPath)
hbs.registerPartials(partialDirctory)
app.use(express.static(publicDirPath))


app.use(express.json())
app.use(bodyParser.json())
app.use(express.urlencoded({
    extended: true
}))

// Set up cokies *************************
app.use(cookieParser());
app.use(session({
    secret: 'gdhfdgfd',
    saveUninitialized: true,
    resave: true,
    cookie: { maxAge: 60000 }
}))

// COnfigure routers ******************************************
app.use(userRouter) //User routers

// app.get('*', (req, res) => {
//     res.render('404Page')    
// })
server.listen(port, () => {
    console.log("Server runs on " + port)
})

